<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Entrada de Material</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <script type="text/javascript">
      function altera(id) {
        var resposta = confirm("Confirma a alteracao deste ítem?");
        if (resposta == true) {
             return true;
        }else{
             return false;
        }
    }
      function remove_item(id) {
        var resposta = confirm("Deseja remover este ítem do pedido?");
        if (resposta == true) {
             return true;
        }else{
             return false;
        }
    }
     function estq_baixo(etq_max) {
        if (add_item.qtd.value > etq_max) {
            alert("Estoque Insuficiente");
            return false;
        }else{
             return true;
        }
    }
      function encerra(id) {
        var resposta = confirm("Deseja realmente encerrar este pedido?");
        if (resposta == true) {
             return true;
        }else{
             return false;
        }
    }

    </script> 
</head>
<body>
  <header>
    <?php
      include "menu.inc";
      if (IsSet($_COOKIE["cod_ent"])){
        $cod_ent = $_COOKIE["cod_ent"];
      }
    ?>
  </header>
  <div class="page_container">  

      <div class="page_form">
        <p class="logo">Entrada de NF</p> <br>
          <table class="search-table" >
                <tr>
                  <th>Cod.</th>
                  <th>NF</th>
                  <th>Empresa</th>
                  <th>Data</th>
                </tr>
        <?php                
              include "conecta_mysql.inc";
              if (!$conexao)
                  die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

              $query =  "SELECT etd.id, etd.nf, e.nome, etd.data_ent
                         FROM tb_entrada AS etd INNER JOIN tb_empresa AS e 
                         ON etd.id = '". $cod_ent ."' AND etd.id_emp = e.id ;";

              $result = mysqli_query($conexao, $query);

              while($fetch = mysqli_fetch_row($result)){
                  echo "<tr><td>" .$fetch[0] . "</td>".
                   "<td>" .$fetch[1] . "</td>".
                   "<td>" .$fetch[2] . "</td>".
                   "<td>" .$fetch[3] . "</td></tr>";
              }

              echo "
                    </table>
              </div>  

                <div class=\"page_form\" id=\"no_margin\">
                  <p class=\"logo\"> Itens</p> <br>
                    <table class=\"search-table\" >
                          <tr>
                            <th>Codigo</th>
                            <th>Descricao</th>
                            <th>Unidade</th>
                            <th>Qtd</th>
                          </tr>";


              $query =  "SELECT p.cod, p.descricao, p.unidade, i.qtd
                        FROM tb_item_compra as i 
                        INNER JOIN tb_produto AS p
                        ON i.id_ent = '". $cod_ent ."' AND i.id_prod = p.id;";

              $result = mysqli_query($conexao, $query);


              $qtd_itens = $result->num_rows;



              while($fetch = mysqli_fetch_row($result)){
                  echo "<tr><td>" .$fetch[0] . "</td>".
                       "<td>" .$fetch[1] . "</td>".
                       "<td>" .$fetch[2] . "</td>".
                       "<td>" .$fetch[3] . "</td></tr>";
              }


              echo"            
                    </table>
              </div>"; 

            if($qtd_itens > 0){
              echo"<div class=\"page_form\" id=\"no_margin\">
                    <form class=\"login-form\" method=\"POST\" action=\"add_item.php\">
                    <table class=\"search-table\"  border=\"0\">
                      <tr>
                        <td><label> Cod.: </label> </td>
                        <td><input type=\"text\" name=\"cod_prod\" maxlength=\"14\"/></td>
                        <td><label> Qtd.: </label> </td>
                        <td><input type=\"text\" name=\"qtd\" maxlength=\"14\"/></td>
                        <td><button name=\"alterar\" id=\"botao_inline\" type=\"submit\" onclick=\"return altera(); return false;\">Alterar</button></td>
                        <td><button name=\"remover\" id=\"botao_inline\" type=\"submit\" onclick=\"return remove_item(); return false;\">Remover</button></td>
                      </tr>
                    </table>
                    <input type=\"hidden\" name=\"cod_ped\" value=\"". $cod_ent ."\">

                    </form>
                  </div> ";   
            }
            $conexao->close();

        

            echo"  <div class=\"page_form\" id=\"no_margin\">
                    <form class=\"login-form\" method=\"POST\" action=\"#\">
                      <p class=\"logo\">Adicionar Itens</p> <br>
                      <table class=\"search-table\"  border=\"0\"><tr><td>
                      <label> Busca por: </label> </td><td>
                      <select name=\"campo\">
                        <option value=\"desc\">Descricao</option>
                        <option value=\"cod\">Codigo</option>
                        <option value=\"forn\">Fornecedor</option>
                        <option value=\"cod_bar\">Codigo do Produto</option>
                      </select></td><td>
                      <input type=\"text\" name=\"valor\" maxlength=\"12\"/></td><td>
                      <button id=\"botao_inline\" type=\"submit\">OK</button></td></tr>  </table>
                    </form>
                  </div>";


        $qtd_lin = 0;
        if (IsSet($_POST ["campo"])){

        include "conecta_mysql.inc";
        if (!$conexao)
          die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

          $campo = $_POST ["campo"];
          $valor = $_POST ["valor"];
          if ($campo == "desc"){
            $query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON p.descricao LIKE '%".$valor."%' AND p.id_emp = e.id ;";
          }
          else
          if ($campo == "cod"){
            $query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON p.cod = '".$valor."' AND p.id_emp = e.id ;";
          }
          else
          if ($campo == "cod_bar"){
            $query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON p.cod_bar = '".$valor."' AND p.id_emp = e.id ;";
          }
          else
          if ($campo == "forn"){

            $query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON e.nome LIKE '%".$valor."%' AND p.id_emp = e.id ;";

          }

          $result = mysqli_query($conexao, $query);

          $qtd_lin = $result->num_rows;



        echo"  <div class=\"page_form\" id=\"no_margin\">
            <table class=\"search-table\" >
                <tr>
                  <th>Codigo</th>
                  <th>Descricao</th>
                  <th>Unid.</th>
                  <th>Estoque</th>
                  <th>Cod. Produto</th>
                  <th>Fornecedor</th>
                </tr>";
                  while($fetch = mysqli_fetch_row($result)){

                    $cod_prod = $fetch[0];
                    $qtd = $fetch[4];

                      echo "<tr><td>" .$fetch[1] . "</td>".
                       "<td>" .$fetch[2] . "</td>".
                         "<td>" .$fetch[3] . "</td>".
                         "<td>" .$fetch[4] . "</td>".
                       "<td>" .$fetch[5] . "</td>".
                       "<td>" .$fetch[6] . "</td></tr>";
                  }
                echo"
            </table> 

          </div>
          ";
        $conexao->close();

        }

      if ($qtd_lin == 1){
          echo"
            <div class=\"page_form\" id= \"no_margin\">
                <table class=\"search-table\"  border=\"0\">
                  <tr>
                    <form name=\"add_item\" class=\"login-form\" method=\"POST\" action=\"add_item_ent.php\" >
                      <td><label> Quantidade </label> </td>
                      <td> <input type=\"text\" name=\"qtd\" /> </td>
                      <td><label> Preço_R$</label> </td>
                      <td> <input type=\"text\" name=\"preco\" /> </td>                      
                      <td>
                        <button name=\"adicionar\" id=\"botao_inline\" type=\"submit\">Adicionar</button>
                        <input type=\"hidden\" name=\"cod_prod\" value=\"". $cod_prod ."\">
                        <input type=\"hidden\" name=\"cod_ent\" value=\"". $cod_ent ."\">
                      </td>
                    </form>
                  </tr>
                </table>

            </form>


          </div>";
      }       
            if($qtd_itens > 0){
              echo"<div class=\"page_form\" id=\"no_margin\">
                    <form class=\"login-form\" method=\"POST\" action=\"add_item.php\">
                    <table class=\"search-table\"  border=\"0\">
                      <tr>
                        <td><button name=\"encerrar\" id=\"botao_inline\" type=\"submit\" onclick=\"return encerra(); return false;\">FINALIZAR ENTRADA</button></td>
                      </tr>
                    </table>
                    <input type=\"hidden\" name=\"cod_ped\" value=\"". $cod_ent ."\">

                    </form>
                  </div> ";   
            }


    ?>      
  </div>

</body>
</html>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Pesquisa por Empresas</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />

    <script type="text/javascript">
	    function confirmacao(id) {
		    var resposta = confirm("Deseja remover esse registro?");
		    if (resposta == true) {
		         return true;
		    }else{
		         return false;
		    }
		}

    </script> 
</head>
<body>
  <header>
    <?php
      include "menu.inc";
    ?>
  </header>
  <div class="page_container">  
  	  <div class="page_form">
  	  	<p class="logo"> Pesquisa por Empresas</p> <br>
  	  	<form class="login-form" method="POST" action="#">
  	  		<table class="search-table"  border="0"><tr><td>
  		  <label> Busca por: </label> </td><td>
	      <select name="campo">
	        <option selected="selected" value="nome">Nome</option>
	        <option value="cli">Clientes</option>
	        <option value="forn">Fornecedores</option>
	        <option value="cnpj">CNPJ</option>
	        <option value="ie">Insc. Estadual</option>
	        <option value="cod">Codigo</option>
	    </select></td><td>

      <input type="text" name="valor" maxlength="12"/></td><td>
	  <button id="botao_inline" type="submit">OK</button></td></tr>  </table>

    	</form>
	  </div>

	  <?php
	  	$qtd_lin = 0;

		    if (IsSet($_POST ["campo"])){

				include "conecta_mysql.inc";
				if (!$conexao)
					die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

			  	$campo = $_POST ["campo"];
			  	$valor = $_POST ["valor"];
			  	if ($campo == "nome"){
			  		$query = "SELECT * FROM tb_empresa WHERE nome LIKE '%".$valor."%'; ";
			  	}
			  	else
			  	if ($campo == "cli"){
			  		$query = "SELECT * FROM tb_empresa WHERE tipo = \"cli\"; ";
			  	}
			  	else
			  	if ($campo == "forn"){
			  		$query = "SELECT * FROM tb_empresa WHERE tipo = \"for\"; ";
			  	}
			  	else
			  	if ($campo == "cnpj"){
			  		$query = "SELECT * FROM tb_empresa WHERE cnpj LIKE '%".$valor."%'; ";
			  	}
			  	else
			  	if ($campo == "ie"){
			  		$query = "SELECT * FROM tb_empresa WHERE ie LIKE '%".$valor."%'; ";
			  	}
			  	else
			  	if ($campo == "cod"){
			  		$query = "SELECT * FROM tb_empresa WHERE id = '" . $valor . "';";
			  	}

			  	$result = mysqli_query($conexao, $query);
				
				$qtd_lin = $result->num_rows;

				echo"  <div class=\"page_form\" id=\"no_margin\">
						<table class=\"search-table\" >
						  	<tr>
						    	<th>Cod.</th>
						    	<th>Nome</th>
						    	<th>Endereco</th>
						    	<th>Cidade</th>
						    	<th>Estado</th>
						    	<th>CNPJ</th>
						    	<th>Insc. Est.</th>
						    	<th>Telefone</th>
						    	<th>Tipo</th>
						  	</tr>";
					        while($fetch = mysqli_fetch_row($result)){

					        	$cod_emp = $fetch[0];

					            echo "<tr><td>" .$fetch[0] . "</td>".
								         "<td>" .$fetch[1] . "</td>".
								         "<td>" .$fetch[4] . "</td>".
								         "<td>" .$fetch[5] . "</td>".
								     	 "<td>" .$fetch[6] . "</td>".
								     	 "<td>" .$fetch[2] . "</td>".
								         "<td>" .$fetch[3] . "</td>".
								         "<td>" .$fetch[8] . "</td>".
								     	 "<td>" .$fetch[7] . "</td></tr>";
					        }
						    echo"
						</table> 

				  </div>
				  ";
				$conexao->close();

		    }


		    if ($qtd_lin == 1){

		    	echo"
			  	  <div class=\"page_form\" id= \"no_margin\">
			  	  		<table class=\"search-table\"  border=\"0\">
			  	  			<tr>
			  	  				<td><form class=\"login-form\" method=\"POST\" action=\"edt_emp.php\">
			  	  					<button id=\"botao_inline\" type=\"submit\">Editar</button>
			  	  					<input type=\"hidden\" name=\"cod_emp\" value=\"". $cod_emp ."\">
			  	  				</form></td>
			  	  				<td><form class=\"login-form\" method=\"POST\" action=\"del_emp.php\" onsubmit=\"return confirmacao(); return false;\"  >
			  	  					<button id=\"botao_inline\" type=\"submit\">Deletar</button>
			  	  					<input type=\"hidden\" name=\"cod_emp\" value=\"". $cod_emp ."\">
			  	  				</form></td>
			  	  			</tr>
			  	  		</table>

			    	</form>


				  </div>";
			}


  	?>

  	  
  </div>
</body>
</html>
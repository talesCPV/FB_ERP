<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Pedido de Compra</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <script type="text/javascript">
	    function confirmacao(id) {
		    var resposta = confirm("Deseja remover esse registro e seus sub ítens?");
		    if (resposta == true) {
		         return true;
		    }else{
		         return false;
		    }
		}

    </script> 
</head>
<body>
  <header>
    <?php
      include "menu.inc";
    ?>
  </header>
  <div class="page_container">  
  	  <div class="page_form">
  	  	<p class="logo"> Pesquisa por Pedido de Compra</p> <br>
  	  	<form class="login-form" method="POST" action="#">
  	  		<table class="search-table"  border="0"><tr><td>
  		  <label> Busca por: </label> </td><td>
	      <select name="campo">
	        <option value="aberto">Em Aberto</option>
	        <option value="fechado">Fechados</option>
	        <option value="todos">Todos</option>
	        <option value="cod">Codigo</option>
	        <option value="num_ped">Num. Pedido</option>
	        <option value="cliente">Cliente</option>
	        <option value="data_emi">Data de Emissao</option>
	    </select></td><td>
      <input type="text" name="valor" maxlength="12"/></td><td>
	  <button id="botao_inline" type="submit">OK</button></td></tr>  </table>

    	</form>
	  </div>

	  <?php

	  		$qtd_lin = 0;
		    if (IsSet($_POST ["campo"])){

				include "conecta_mysql.inc";
				if (!$conexao)
					die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

			  	$campo = $_POST ["campo"];
			  	$valor = $_POST ["valor"];
			  	if ($campo == "todos"){

	              $query =  "SELECT p.id, p.num_ped, e.nome, p.comp, p.data_ped, p.data_ent, p.status
	                         FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
	                         ON p.id_emp = e.id ;";

			  	}
			  	else
			  	if ($campo == "num_ped"){
	              $query =  "SELECT p.id, p.num_ped, e.nome, p.comp, p.data_ped, p.data_ent, p.status
	                         FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
	                         ON p.id_emp = e.id AND p.num_ped = '". $valor ."';";
			  	}
			  	else
			  	if ($campo == "cliente"){
	              $query =  "SELECT p.id, p.num_ped, e.nome, p.comp, p.data_ped, p.data_ent, p.status
	                         FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
	                         ON p.id_emp = e.id AND e.nome LIKE '%".$valor."%';";

			  	}
			  	else
			  	if ($campo == "data_emi"){
	              $query =  "SELECT p.id, p.num_ped, e.nome, p.comp, p.data_ped, p.data_ent, p.status
	                         FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
	                         ON p.id_emp = e.id AND p.data_ped = '". $valor ."';";
			  	}
			  	else
			  	if ($campo == "aberto"){
	              $query =  "SELECT p.id, p.num_ped, e.nome, p.comp, p.data_ped, p.data_ent, p.status
	                         FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
	                         ON p.id_emp = e.id AND p.status = 'ABERTO';";
			  	}
			  	else
			  	if ($campo == "fechado"){
	              $query =  "SELECT p.id, p.num_ped, e.nome, p.comp, p.data_ped, p.data_ent, p.status
	                         FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
	                         ON p.id_emp = e.id AND p.status = 'FECHADO';";
			  	}
			  	else
			  	if ($campo == "cod"){
	              $query =  "SELECT p.id, p.num_ped, e.nome, p.comp, p.data_ped, p.data_ent, p.status
	                         FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
	                         ON p.id_emp = e.id AND p.id = '". $valor ."';";
			  	}

//			  	echo $query;

			  	$result = mysqli_query($conexao, $query);

			  	$qtd_lin = $result->num_rows;



				echo"  <div class=\"page_form\" id=\"no_margin\">
						<table class=\"search-table\" >
			                <tr>
			                  <th>Cod.</th>
			                  <th>Num. Ped.</th>
			                  <th>Cliente</th>
			                  <th>Comprador</th>
			                  <th>Data</th>
			                  <th>Entrega</th>
			                  <th>Status</th>
						  	</tr>";
					        while($fetch = mysqli_fetch_row($result)){

					        	$cod_ped = $fetch[0];
					        	$status = $fetch[6];

					            echo "<tr><td>" .$fetch[0] . "</td>".
								     	 "<td>" .$fetch[1] . "</td>".
								     	 "<td>" .$fetch[2] . "</td>".
								         "<td>" .$fetch[3] . "</td>".
								         "<td>" . date('d/m/Y', strtotime($fetch[4])) . "</td>".
								         "<td>" . date('d/m/Y', strtotime($fetch[5])) . "</td>".
								     	 "<td>" .$fetch[6] . "</td></tr>";
					        }



						    echo"
						</table> 

				  </div>
				  ";
				$conexao->close();

		    }

			if ($qtd_lin == 1){
		    	echo"
			  	  <div class=\"page_form\" id= \"no_margin\">
			  	  		<table class=\"search-table\"  border=\"0\">
			  	  			<tr>
			  	  				<td><form class=\"login-form\" method=\"POST\" action=\"edita_ped.php\">
			  	  					<input type=\"hidden\" name=\"cod_ped\" value=\"". $cod_ped ."\">
			  	  					<button id=\"botao_inline\" type=\"submit\">Visualizar</button>
			  	  				</form></td>
			  	  				<td><form class=\"login-form\" method=\"POST\" action=\"del_ped.php\" onsubmit=\"return confirmacao(); return false;\"  >
			  	  					<input type=\"hidden\" name=\"cod_ped\" value=\"". $cod_ped ."\">
			  	  					<input type=\"hidden\" name=\"status\" value=\"". $status ."\">
			  	  					<button id=\"botao_inline\" type=\"submit\">Deletar</button>
			  	  				</form></td>
			  	  			</tr>
			  	  		</table>
			    	</form>


				  </div>";
			}		    

	  ?>
  	  
  </div>



</body>
</html>
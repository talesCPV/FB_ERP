<?php 
// RECEBENDO OS DADOS PREENCHIDOS DO FORMUL�RIO !
    $num_ped = $_POST ["num_ped"];
    $cliente = $_POST ["cliente"];
    $data_ped = $_POST ["data_ped"];
    $data_ent  = $_POST ["data_ent"];
    $comp  = $_POST ["comprador"];
    $resp    = $_POST ["responsavel"];

include "conecta_mysql.inc";

if (IsSet($_POST ["num_ped"])){
	$cod_prod = $_POST ["num_ped"];
	if (!$conexao)
		die ("Erro de conex�o com localhost, o seguinte erro ocorreu -> ".mysql_error());

	$query = "INSERT INTO tb_pedido ( id_emp, data_ped, data_ent, resp, comp, num_ped)
			 VALUES ('$cliente', '$data_ped', '$data_ent','$resp', '$comp', '$num_ped')";   
	
	mysqli_query($conexao, $query);

	$query = "SELECT MAX(Id) FROM tb_pedido;";

	$result = mysqli_query($conexao, $query);

	while($fetch = mysqli_fetch_row($result)){

                    $cod_ped = $fetch[0];
          }

	setcookie("message", "Pedido cadastrado com sucesso!", time()+3600);
	setcookie("cod_ped", $cod_ped , time()+3600);

	$conexao->close();

}else{
	setcookie("message", "Houve algum problema na grava��o."   , time()+3600);	
}

header('Location: cad_item_ped.php');

?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Cadastro de Empresas</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <script type="text/javascript">
    function validaCampo()
    {
    if(document.cadastro.nome.value=="")
      {
      alert("O Campo nome é obrigatório!");
      return false;
      }
    else
      return true;
    }

    <!-- Fim do JavaScript ! -->
    </script>
</head>
<body>
  <header>
    <?php
      include "menu.inc";
      // RECEBENDO OS DADOS PREENCHIDOS DO FORMULÁRIO !
      if (IsSet($_POST ["cod_emp"])){

        $cod_emp = $_POST ["cod_emp"];

        include "conecta_mysql.inc";
        if (!$conexao)
          die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());


        $query = "SELECT * FROM tb_empresa WHERE id = ".$cod_emp."; ";
          
        $result = mysqli_query($conexao, $query);

        while($fetch = mysqli_fetch_row($result)){

                    $nome = $fetch[1];
                    $endereco = $fetch[4];
                    $cidade = $fetch[5];
                    $estado = $fetch[6];
                    $cep = $fetch[9];
                    $cnpj = $fetch[2];
                    $ie = $fetch[3];
                    $tipo = $fetch[7];
                    $telefone = $fetch[8];

        }


      }

      $conexao->close();

    ?>
  </header>

<div class="page_container">  
  <div class="page_form">
    <p class="logo"> Cadastro de Empresas</p> <br>
    <form class="login-form" name="cadastro" method="POST" action="save_emp.php" onsubmit="return validaCampo(); return false;">
      <label> Nome </label>
      <input type="text" name="nome" maxlength="50" value="<?php echo "$nome" ?>" />
      <label> Endereço </label>
      <input type="text" name="endereco" maxlength="60" value="<?php echo "$endereco" ?>" />
      <label> Cidade </label>
      <input type="text" name="cidade" maxlength="30" value="<?php echo "$cidade" ?>" />
      <label> Estado </label>
      <select name="estado" id="estado">
        <option value="AC">Acre</option>
        <option value="AL">Alagoas</option>
        <option value="AP">Amapa</option>
        <option value="AM">Amazonas</option>
        <option value="BA">Bahia</option>
        <option value="CE">Ceara</option>
        <option value="ES">Espirito Santo</option>
        <option value="DF">Distrito Federal</option>
        <option value="MA">Maranhao</option>
        <option value="MT">Mato Grosso</option>
        <option value="MS">Mato Grosso do Sul</option>
        <option value="MG">Minas Gerais</option>
        <option value="PA">Para</option>
        <option value="PB">Paraiba</option>
        <option value="PR">Parana</option>
        <option value="PE">Pernambuco</option>
        <option value="PI">Piaui</option>
        <option value="RJ">Rio de Janeiro</option>
        <option value="RN">Rio Grande do Norte</option>
        <option value="RS">Rio Grande do Sul</option>
        <option value="RO">Rondonia</option>
        <option value="RR">Roraima</option>
        <option value="SC">Santa Catarina</option>
        <option selected="selected" value="SP">Sao Paulo</option>
        <option value="SE">Sergipe</option>
        <option value="TO">Tocantins</option>
      </select>
      <label> CEP </label>
      <input type="text" name="cep" maxlength="10" value="<?php echo "$cep" ?>" />
      <label> CNPJ </label>
      <input type="text" name="cnpj" maxlength="14" value="<?php echo "$cnpj" ?>" />
      <label> Inscrição Estadual </label>
      <input type="text" name="ie" maxlength="14" value="<?php echo "$ie" ?>" />
      <label> Tipo </label>
      <select name="tipo">
        <option value="FOR">Fornecedor</option>
        <option value="CLI">Cliente</option>
      </select>
      <label> Telefone </label>
      <input type="text" name="fone" maxlength="14" value="<?php echo "$telefone" ?>" />
      <input type="hidden" name="cod_emp" value="<?php echo "$cod_emp" ?>">
      <button type="submit">Cadastrar</button>

    </form>
  </div>
</div>

</body>
</html>
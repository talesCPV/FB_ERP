<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Pedido de Compra</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <script type="text/javascript">
    function validaCampo()
    {
    if(document.cadastro.nome.value=="")
      {
      alert("O Campo \"Num. Pedido\" é obrigatório!");
      return false;
      }
  
    else
      return true;
    }

    <!-- Fim do JavaScript ! -->
    </script>
</head>
<body>
  <header>

    <?php
      include "menu.inc";
    ?>
  </header>

<div class="page_container">  
  <div class="page_form">
    <p class="logo"> Cadastrar Pedido de Compra</p> <br>
    <form class="login-form" name="cadastro" method="POST" action="save_ped.php" onsubmit="return validaCampo(); return false;">
      <label> Num. Pedido * </label>
      <input type="text" name="num_ped" maxlength="15" />
      <label> Cliente </label>
      <?php  

      include "conecta_mysql.inc";
      if (!$conexao)
        die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

        $query = "SELECT * from tb_empresa where tipo = \"CLI\"";
        $result = mysqli_query($conexao, $query);

          echo "<td><select name=\"cliente\" id=\"emp\">";

        while($fetch = mysqli_fetch_row($result)){
            echo $fetch[1] . "<br>";
            echo "<option value=\"". $fetch[0] ."\">". $fetch[1] ."</option>";
        }

            echo "</select> </td>";
          $conexao->close();
      ?>
      <label> Data </label>
      <input type="date" name="data_ped" value="<?php echo date('Y-m-d'); ?>">
      <label> Data de Entrega </label>
      <input type="date" name="data_ent" >
      <label> Comprador</label>
      <input type="text" name="comprador" maxlength="30" />
      <label> Emitido por</label>
      <input type="text" name="responsavel" value="<?php if (IsSet($_COOKIE["usuario"])){ echo $_COOKIE["usuario"]; } ?>" readonly/>
      <button type="submit">Salvar</button>

    </form>
  </div>
</div>

</body>
</html>
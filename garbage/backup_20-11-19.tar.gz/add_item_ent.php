<?php 

include "conecta_mysql.inc";

if (!$conexao)
	die ("Erro de conex�o com localhost, o seguinte erro ocorreu -> ".mysql_error());

$destino = 'cad_item_ent.php';

function get_post_action($name)
{
    $params = func_get_args();

    foreach ($params as $name) {
        if (isset($_POST[$name])) {
            return $name;
        }
    }
}


if (IsSet($_POST ["cod_ent"])){
    $cod_ent = $_POST ["cod_ent"];
}

switch (get_post_action('adicionar', 'alterar', 'remover', 'encerrar')) {
    case 'adicionar':
	    $cod_prod = $_POST ["cod_prod"];
	    $preco = $_POST ["preco"];
	    $qtd = $_POST ["qtd"];
		$query = "INSERT INTO tb_item_compra ( id_prod, id_ent, qtd, preco) VALUES ('$cod_prod', '$cod_ent', '$qtd', '$preco')";   
        break;

    case 'alterar':
	    $cod_prod = $_POST ["cod_prod"];
	    $qtd = $_POST ["qtd"];

		$query = "UPDATE tb_item_ped i
				  INNER JOIN tb_produto p
				  SET qtd = '$qtd'
				  WHERE i.id_ped = '$cod_ped'
				  AND p.cod = '$cod_prod'
				  AND p.id = i.id_prod;";
        break;

    case 'remover':
	    $cod_item = $_POST ["cod_prod"];
		$query = "DELETE i
				  FROM tb_item_ped i
				  INNER JOIN tb_produto p
				  ON p.id = i.id_prod
				  WHERE p.cod = '$cod_item' AND i.id_ped = '$cod_ped';";
        break;

    case 'encerrar':
		$query = "SELECT id_prod, qtd from tb_item_ped where id_ped = '$cod_ped';";		
//			echo $query ."<br>";

          $result = mysqli_query($conexao, $query);

          while($fetch = mysqli_fetch_row($result)){
        	$id_prod = $fetch[0];
        	$qtd = $fetch[1];
			$query = "UPDATE tb_produto
					  SET estoque = estoque - '$qtd'
					  WHERE id = '$id_prod';";
			mysqli_query($conexao, $query);
//			echo $query ."<br>";

        }

		$query = "UPDATE tb_pedido
				  SET status = 'FECHADO'
				  WHERE id = '$cod_ped';";
//		echo "<br>".$query ."<br>";


		$destino = 'main.php';
		setcookie("message", "Pedido encerrado com sucesso!", time()+3600);
        break;
    default:
        //no action sent
	}
	mysqli_query($conexao, $query);
	$conexao->close();
	header('Location: '. $destino);
?>
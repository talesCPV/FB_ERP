<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Pesquisa por Produto</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <script type="text/javascript">
	    function confirmacao(id) {
		    var resposta = confirm("Deseja remover esse registro?");
		    if (resposta == true) {
		         return true;
		    }else{
		         return false;
		    }
		}

    </script> 
</head>
<body>
  <header>
    <?php
      include "menu.inc";
    ?>
  </header>
  <div class="page_container">  
  	  <div class="page_form">
  	  	<p class="logo"> Pesquisa por Produto</p> <br>
  	  	<form class="login-form" method="POST" action="#">
  	  		<table class="search-table"  border="0"><tr><td>
  		  <label> Busca por: </label> </td><td>
	      <select name="campo">
	        <option value="desc">Descricao</option>
	        <option value="forn">Fornecedor</option>
	        <option value="cod">Codigo</option>
	        <option value="cod_bar">Codigo de Barras</option>
	        <option value="etq_min">Estoque baixo</option>
	    </select></td><td>
      <input type="text" name="valor" maxlength="12"/></td><td>
	  <button id="botao_inline" type="submit">OK</button></td></tr>  </table>

    	</form>
	  </div>

	  <?php

	  		$qtd_lin = 0;
		    if (IsSet($_POST ["campo"])){

				include "conecta_mysql.inc";
				if (!$conexao)
					die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

			  	$campo = $_POST ["campo"];
			  	$valor = $_POST ["valor"];
			  	if ($campo == "desc"){
			  		$query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, p.ncm, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON p.descricao LIKE '%".$valor."%' AND p.id_emp = e.id ;";
			  	}
			  	else
			  	if ($campo == "cod"){
			  		$query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, p.ncm, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON p.cod = '".$valor."' AND p.id_emp = e.id ;";
			  	}
			  	else
			  	if ($campo == "cod_bar"){
			  		$query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, p.ncm, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON p.cod_bar = '".$valor."' AND p.id_emp = e.id ;";
			  	}
			  	else
			  	if ($campo == "etq_min"){
			  		$query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, p.ncm, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON p.estoque <= p.etq_min AND p.id_emp = e.id ;";
			  	}
			  	else
			  	if ($campo == "forn"){

			  		$query =  "SELECT p.id, p.cod, p.descricao, p.unidade, p.estoque, p.cod_bar, p.ncm, e.nome FROM tb_produto AS p INNER JOIN tb_empresa AS e ON e.nome LIKE '%".$valor."%' AND p.id_emp = e.id ;";

			  	}

			  	$result = mysqli_query($conexao, $query);

			  	$qtd_lin = $result->num_rows;



				echo"  <div class=\"page_form\" id=\"no_margin\">
						<table class=\"search-table\" >
						  	<tr>
						    	<th class=\"center_text\">Cod.</th>
						    	<th class=\"center_text\">Descricao</th>
						    	<th class=\"center_text\">Und.</th>
						    	<th class=\"center_text\">Estq.</th>
						    	<th class=\"center_text\">Cod. Prod.</th>
						    	<th class=\"center_text\">NCM</th>
						    	<th class=\"center_text\">Fornecedor</th>
						  	</tr>";
					        while($fetch = mysqli_fetch_row($result)){

					        	$cod_prod = $fetch[0];

					            echo "<tr><td class=\"center_text\" >" .$fetch[1] . "</td>".
								     	 "<td>" .$fetch[2] . "</td>".
								         "<td class=\"center_text\">" .$fetch[3] . "</td>".
								         "<td class=\"center_text\">" .$fetch[4] . "</td>".
								     	 "<td class=\"center_text\">" .$fetch[5] . "</td>".
								     	 "<td class=\"center_text\">" .$fetch[6] . "</td>".
								     	 "<td>" .$fetch[7] . "</td></tr>";
					        }
						    echo"
						</table> 

				  </div>
				  ";
				$conexao->close();

		    }

			if ($qtd_lin == 1){

		    	echo"
			  	  <div class=\"page_form\" id= \"no_margin\">
			  	  		<table class=\"search-table\"  border=\"0\">
			  	  			<tr>
			  	  				<td><form class=\"login-form\" method=\"POST\" action=\"edt_prod.php\">
			  	  					<button id=\"botao_inline\" type=\"submit\">Editar</button>
			  	  					<input type=\"hidden\" name=\"cod_prod\" value=\"". $cod_prod ."\">
			  	  				</form></td>
			  	  				<td><form class=\"login-form\" method=\"POST\" action=\"del_prod.php\" onsubmit=\"return confirmacao(); return false;\"  >
			  	  					<button id=\"botao_inline\" type=\"submit\">Deletar</button>
			  	  					<input type=\"hidden\" name=\"cod_prod\" value=\"". $cod_prod ."\">
			  	  				</form></td>
			  	  			</tr>
			  	  		</table>

			    	</form>


				  </div>";
			}		    

	  ?>
  	  
  </div>



</body>
</html>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Configuracoes</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
</head>
<body>


  <header>
    <?php
      include "menu.inc";
      if (IsSet($_POST ["memo"])){
         $texto = $_POST ["memo"];
         $fp = fopen("unidades.txt", "w");
         fwrite($fp, $texto);
         fclose($fp);
      }

    ?>
  </header>

<div class="page_container">  
  <div class="page_form">
    <p class="logo"> Configuracao</p> <br>
    <form class="login-form" name="cadastro" method="POST" action="#" onsubmit="return validaCampo(); return false;">
      <label> Unidades de Medida </label>

      <textarea name="memo" cols="112" rows="5" ><?php  
          $fp = fopen("unidades.txt", "a+");
          while (!feof ($fp)) {
            $valor = fgets($fp,4096);
            echo $valor;
          }
          fclose($fp);
      ?></textarea>

      <button type="submit">Salvar</button>

    </form>    
  </div>
</div>


</body>
</html>
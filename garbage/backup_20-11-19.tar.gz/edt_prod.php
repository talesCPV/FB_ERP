<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Cadastro de Produtos</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <script type="text/javascript">

    var caracteresPossiveis = new Array('1','2','3','4','5','6','7','8','9','0','.');
    var qtdCaracteres = caracteresPossiveis.length;

    function validaCampo()
    {
    if(document.cadastro.nome.value=="")
      {
      alert("O Campo \"Descrição\" é obrigatório!");
      return false;
      }
    else
    if(document.cadastro.cod.value=="")
      {
      alert("O Campo \"Codigo\" é obrigatório e nao pode se repetir!");
      return false;
      }
    else
      return true;
    }


    function verificaCaractere(campo){
        var texto = campo.value;
        var qtdCaracteresCampo = campo.value.length;

        var textoSemUltimoCaractere = texto.slice(0, qtdCaracteresCampo-1);
        var ultimoCaractere = texto.charAt(qtdCaracteresCampo-1);

        var permitido = false;
        //alert(texto+"  "+qtdCaracteres+" "+textoSemUltimoCaractere+" "+ultimoCaractere+" "+permitido+" "+qtdCaracteresCampo);
        for(var i = 0; i<qtdCaracteres; i++){
            if(ultimoCaractere==caracteresPossiveis[i]){
                permitido = true;
            }
        }
        if(permitido==false){
            campo.value = textoSemUltimoCaractere;
        }
    }



    </script>
</head>
<body>
  <header>
    <?php
      include "menu.inc";
      // RECEBENDO OS DADOS PREENCHIDOS DO FORMULÁRIO !
      if (IsSet($_POST ["cod_prod"])){

        $cod_prod = $_POST ["cod_prod"];

        include "conecta_mysql.inc";
        if (!$conexao)
          die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());


        $query = "SELECT * FROM tb_produto WHERE id = ".$cod_prod."; ";
          
        $result = mysqli_query($conexao, $query);

        while($fetch = mysqli_fetch_row($result)){
          $id_emp = $fetch[1];
          $descricao = $fetch[2];
          $estoque = $fetch[3];
          $etq_min = $fetch[4];
          $unidade = $fetch[5];
          $ncm = $fetch[6];
          $cod = $fetch[7];
          $cod_bar = $fetch[8];
          $compra = $fetch[10];
          $margem = $fetch[11];
        }


      }

      $conexao->close();
    ?>
  </header>

<div class="page_container">  
  <div class="page_form">
    <p class="logo"> Cadastro de Produtos</p> <br>
    <form class="login-form" name="cadastro" method="POST" action="save_prod.php" onsubmit="return validaCampo(); return false;">
      <label> Descrição * </label>
      <input type="text" name="nome" maxlength="80" value="<?php echo "$descricao" ?>" />
      <label> Fornecedor </label>
      <?php  

      include "conecta_mysql.inc";
      if (!$conexao)
        die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

        $query = "SELECT * from tb_empresa where tipo = \"FOR\"";
        $result = mysqli_query($conexao, $query);

          echo "<td><select name=\"forn\" id=\"forn\">";


        while($fetch = mysqli_fetch_row($result)){
            if ($id_emp == $fetch[0]){
              echo "<option selected=\"selected\" value=\"". $fetch[0] ."\">". $fetch[1] ."</option>";
            }else{
              echo "<option value=\"". $fetch[0] ."\">". $fetch[1] ."</option>";
            }            
        }

            echo "</select> </td>";
          $conexao->close();
      ?>
      <label> Unidade </label> 
      <?php  // busca unidades no
          $arquivo = "unidades.txt";
          $fp = fopen($arquivo, "r");
          echo "<td><select name=\"und\" >";
          while (!feof ($fp)) {
            $valor = fgets($fp, 4096);
            if( trim($unidade) == trim($valor)){
              echo "<option selected=\"selected\" value=\"". $valor ."\">". $valor ."</option>";
            }else{
              echo "<option value=\"". $valor ."\">". $valor ."</option>";
            }
          }

          echo "</select> </td>";

          fclose($fp);
      ?>
      <label> Estoque </label>
      <input type="text" name="estoque" maxlength="6" value="<?php echo "$estoque" ?>"/>
      <label> Estoque Minimo </label>
      <input type="text" name="est_min" maxlength="4" value="<?php echo "$etq_min" ?>"/>
      <label> Codigo *</label>
      <input type="text" name="cod" maxlength="15" value="<?php echo "$cod" ?>"/>
      <label> Codigo do Produto </label>
      <input type="text" name="cod_bar" maxlength="15" value="<?php echo "$cod_bar" ?>"/>
      <label> NCM </label>
      <input type="text" name="ncm" maxlength="10" value="<?php echo "$ncm" ?>"/>
      <label> Preço de Compra R$</label>
      <input type="text" name="compra" maxlength="15" value="<?php echo "$compra" ?>" onkeyup="return verificaCaractere(this)"/>
      <label> Margem %</label>
      <input type="text" name="margem" maxlength="15" value="<?php echo "$margem" ?>" onkeyup="return verificaCaractere(this)"/>
      <input type="hidden" name="cod_prod" value="<?php echo "$cod_prod" ?>">
      <button type="submit">Salvar</button>

    </form>
  </div>
</div>

</body>
</html>
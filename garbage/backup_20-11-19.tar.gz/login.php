<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Login</title>
     <!-- Aqui chamamos o nosso arquivo css externo -->
    <link rel="stylesheet" type="text/css"  href="estilo.css" />
    <!--[if lte IE 8]>
 <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
 <![endif]-->   
</head>
<body>

<div class="login-page">
  <div class="form">
    <p class="logo"> <a href="https://www.flexibus.com.br"><img src="img/logo.png"></a></p> <br>
    <form class="login-form" method="POST" action="connect.php">
      <input type="text" placeholder="username" name="user" />
      <input type="password" placeholder="password" name="pass" />
      <button>login</button>

    </form>
  </div>
</div>

</body>
</html>
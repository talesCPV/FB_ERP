<?php
    $cab = "config/nfe.cfg \r\n";
    $it = "config/itens.cfg \r\n";

  function download($arquivo){
      header("Content-Type: application/force-download");
        header("Content-Type: application/octet-stream;");
        header("Content-Length:".filesize($arquivo));
        header("Content-disposition: attachment; filename=".$arquivo);
        header("Pragma: no-cache");
        header("Cache-Control: no-store, no-cache, must-revalidate, post-check=0, pre-check=0");
        header("Expires: 0");
        readfile($arquivo);
        flush();
  }

  $fp = fopen($cab, "r");
   $conteudo = fread($fp, filesize($cab));
  fclose($fp);

  $fp = fopen($it, "r");
   $conteudo = $conteudo . fread($fp, filesize($it));
  fclose($fp);

  $fp = fopen("config/NOTAFISCAL.txt", "w");
  fwrite($fp, $conteudo);
  fclose($fp);


    download("config/NOTAFISCAL.txt");



?>
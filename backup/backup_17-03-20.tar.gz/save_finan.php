<?php 
// RECEBENDO OS DADOS PREENCHIDOS DO FORMUL�RIO !
$user	= $_POST ["user"];
$pass	= $_POST ["pass"];
$classe	= $_POST ["classe"];

include "conecta_mysql.inc";
if (!$conexao)
	die ("Erro de conex�o com localhost, o seguinte erro ocorreu -> ".mysql_error());

         
$tipo = $_POST ["tipo"];
$ref = $_POST ["ref"];
$dest = $_POST ["dest"];
$valor = $_POST ["valor"];
$venc = $_POST ["data_venc"];
$lanc = date('Y-m-d');
$resp = $_POST ["resp"];
$orig = $_POST ["origem"];

$query = "INSERT INTO tb_financeiro ( tipo, ref, emp, preco, data_pg, data_ini, resp, origem) VALUES ('$tipo', '$ref', '$dest', '$valor','$venc', '$lanc' ,'$resp','$orig');";   

mysqli_query($conexao, $query);
$conexao->close();            

header('Location: cad_lanc.php');
?>


<?php 
	setcookie("logado");
	header('Location: login.php');
?>

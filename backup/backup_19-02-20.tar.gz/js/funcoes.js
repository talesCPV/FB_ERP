/* SCRIPTS DE VALIDAÇÃO DE DADOS - SISTEMA FLEXIBUS*/      

      function confirma(msg) {
        return confirm(msg);
    }


    function validaCampo(obj)
    {
        for(var i = 0; i<obj.length; i++){
    
            if(obj[i].value=="")
              {
                  alert("Os campos com * são obrigatórios!");
                  return false;
              }
        }
        return true;
    }

     function estq_baixo(etq_max) {
        if (add_item.qtd.value > etq_max) {
            alert("Estoque Insuficiente !!");
            return false;
        }else{
             return true;
        }
    }


    function valida_senha(obj)
    {
        if(obj[1].value != obj[2].value)
          {
              alert("O campo \"Repita a senha\" não confere!");
              return false;
          }

        if (validaCampo(obj)){
            return true;
        }else{
            return false;
        }
    }

 
    function money(campo){
        var ok_chr = new Array('1','2','3','4','5','6','7','8','9','0');
        var text = campo.value;
        var after_dot = 0;
        var out_text = '';
        for(var i = 0; i<text.length; i++){

            if(after_dot > 0){ // conta quantas casas depois da virgula
                after_dot = after_dot + 1;
            }

            if (after_dot < 4 ){ // se não passou de 2 casas depois da virgula ( conta o ponto + 2 digitos)

                if(ok_chr.includes(text.charAt(i))){
                    out_text = out_text + text.charAt(i)

                }
                if((text.charAt(i) == ',' || text.charAt(i) == '.') && after_dot == 0){
                    out_text = out_text + '.';
                    after_dot = after_dot + 1;
                }
            }


        }
        campo.value = out_text;
    }


//JQUERY
$(document).ready(function(){


    // POPUP CLOSE
    $('.close').click(function(){ // BOTÃO FECHAR DO POPUP
        $(".overlay").css("visibility", "hidden").css("opacity", "0");

    }); 

    // DUPLO CLIQUE NA TEBELA tabItens
    $('#tabItens').on('dblclick','.tbl_row', function(){ // SELECIONANDO UM ÍTEM DA TABELA (DUPLO CLIQUE)

        var arr = window.location.href.split("/");
        var id = $(this).attr('id');

//        alert(arr[arr.length-1]);

        switch (arr[arr.length-1]){
        case 'pesq_ped.php#': // PÁGINA PESQ_PED (PESQUISA DE PEDIDOS)
    
            var num = $.trim($(this).children('td').slice(1, 2).text());
            var cli = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var comp = $.trim($(this).children('td').slice(3, 4).text().toUpperCase());
            var data = $.trim($(this).children('td').slice(4, 5).text());
            var status = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var table = "<table><tr><td>Cliente:</td><td>"+cli+"</td></tr><td>Comprador:</td><td>"+comp+"</td></tr><td>Data:</td><td>"+data+"</td></tr><td>Status:</td><td>"+status+"</td></tr></table>";
            var form = "<form id='frmPesqPed' method='POST' action='pdf_analise.php'><input type='hidden' name='cod_ped' value='"+id+"'><input type='hidden' name='status' value='"+status+"'></form>";
            var Btn = "<table><tr><td><button id='btnAnalisar'>Analisar</button></td><td><button id='btnVisualizar'>Visualizar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";

            $(document).off('click', '#btnAnalisar').on('click', '#btnAnalisar', function() {
                $('#frmPesqPed').attr('action', 'pdf_analise.php');
                $('#frmPesqPed').submit();
            });

            $(document).off('click', '#btnVisualizar').on('click', '#btnVisualizar', function() {
                $('#frmPesqPed').attr('action', 'edita_ped.php');
                $('#frmPesqPed').submit();
            });

            $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                if (confirm('Deseja remover o ítem definitivamente do sistema?')) {
                    $('#frmPesqPed').attr('action', 'del_ped.php');
                    $('#frmPesqPed').submit();
                }
            });

            $(".content").html(table+form+Btn);
            $('#popTitle').html(num);

            break;
        case 'pesq_prod.php#':

            var nome = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
            var und = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var etq = $.trim($(this).children('td').slice(3, 4).text().toUpperCase());
            var codprod = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
            var forn = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var preco = $.trim($(this).children('td').slice(6, 7).text().toUpperCase());
            var table = "<table><tr><td>unidade</td><td>"+und+"</td></tr><td>Estoque</td><td>"+etq+"</td></tr><td>Cód. Fab</td><td>"+codprod+"</td></tr><td>Preço</td><td>"+preco+"</td></tr></table>";
            var form = "<form id='frmPesqProd' method='POST' action='edt_prod.php'><input type='hidden' name='cod_prod' value='"+id+"'></form>";
            var Btn = "<table><tr><td><button id='btnEditar'>Editar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";

            $(document).off('click', '#btnEditar').on('click', '#btnEditar', function() {
                $('#frmPesqProd').attr('action', 'edt_prod.php');
                $('#frmPesqProd').submit();
            });

            $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                if (confirm('Deseja remover o ítem definitivamente do sistema?')) {
                    $('#frmPesqProd').attr('action', 'del_prod.php');
                    $('#frmPesqProd').submit();
                }
            });

            $(".content").html(table+form+Btn);
            $('#popTitle').html(nome);

            break;

        case 'pesq_ent.php#':

            var nf = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
            var forn = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var data = $.trim($(this).children('td').slice(3, 4).text());
            var status = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
            var resp = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var table = "<table><tr><td>Nota Fiscal:</td><td>"+nf+"</td></tr><td>Fornecedor:</td><td>"+forn+"</td></tr><td>Data:</td><td>"+data+"</td></tr><td>Status:</td><td>"+status+"</td></tr></table>";
            var form = "<form id='frmPesqEnt' method='POST' action='edita_ent.php'><input type='hidden' name='cod_ent' value='"+id+"'><input type='hidden' name='status' value='"+status+"'></form>";
            var Btn = "<table><tr><td><button id='btnVisualizar'>Visualizar</button><button id='btnDeletar'>Deletar</button></td></tr></table>";

            $(document).off('click', '#btnVisualizar').on('click', '#btnVisualizar', function() {
                $('#frmPesqEnt').attr('action', 'edita_ent.php');
                $('#frmPesqEnt').submit();
            });

            $(document).off('click', '#btnDeletar').on('click', '#btnDeletar', function() {
                if (confirm('Deseja remover o ítem definitivamente do sistema?')) {
                    $('#frmPesqEnt').attr('action', 'del_ent.php');
                    $('#frmPesqEnt').submit();
                }
            });

            $(".content").html(table+form+Btn);
            $('#popTitle').html(forn+' NF:'+nf);

            break;
        case 'cad_item_ped.php#': // nfe_conf.php#

            var codProd = $.trim($(this).children('td').slice(0, 1).text().toUpperCase());
            var desc = $.trim($(this).children('td').slice(1, 2).text().toUpperCase());
            var und = $.trim($(this).children('td').slice(2, 3).text().toUpperCase());
            var etq = $.trim($(this).children('td').slice(3, 4).text());
            var preco = $.trim($(this).children('td').slice(4, 5).text().toUpperCase());
            var forn = $.trim($(this).children('td').slice(5, 6).text().toUpperCase());
            var codPed = $.trim($(this).children('td').slice(6, 7).text().toUpperCase());
            var tipo = $.trim($(this).children('td').slice(7, 8).text().toUpperCase());
            var table = "<table><td>Und.:</td><td>"+und+"</td></tr><td>Preço:</td><td>"+ preco +"</td></tr><td>Forn.:</td><td>"+forn+"</td></tr></table>";
            var form = "<form id='frmAddItem' method='POST' action='add_item.php'><input type='hidden' name='preco' value='"+ $(this).moeda(preco) +"'><input type='hidden' name='op' value='add'><input type='hidden' name='cod_prod' value='"+id+"'><input type='hidden' name='und' value='"+und+"'><input type='hidden' name='cod_ped' value='"+codPed+"'><input type='hidden' name='tipo' value='"+tipo+"'>";
            var Btn = "<table><tr><td><label> Quantidade </label></td><td><input id='edtQtd' type='text' name='qtd'/></td>";
            if(tipo == 'TINTA'){
                Btn = Btn + " <td><select name='vol'><option value='0.5'>450ml</option><option selected='selected' value='1'>900ml</option><option value='2'>1.8L</option><option value='3'>2.7L</option><option value='4'>3.6L</option></select></td>";
            }else{
                Btn = Btn + "<input type='hidden' name='vol' value='1'>";
            }

            Btn = Btn + "<td><button name='adicionar' id='btnAdd'>Adicionar</button></td></tr></table></form>";

            $(document).off('click', '#btnAdd').on('click', '#btnAdd', function() {
                $('#frmAddItem').submit();
            });

            $(document).off('keyup', '#edtQtd').on('keyup', '#edtQtd', function() {
                txt = $('#edtQtd').val()
                $("#edtQtd").val($(this).numeros(txt));
            });         

            $(".content").html(table+form+Btn);
            $('#popTitle').html(desc);

            break;     
        case 'nfe_conf.php#':

            $('#selBusca').val('cod');
            $('#edtBusca').val(id);
            $('#botao_inline').trigger('click');

            break;            
        case 'cad_etq.php#':

            $('#selBusca').val('cod');
            $('#edtBusca').val(id);
            $('#botao_inline').trigger('click');

            break; 
        case 'cad_item_ent.php#':

            $('#selBusca').val('cod');
            $('#edtBusca').val(id);
            $('#botao_ok').trigger('click');

            break;             
            
        }

        $(".overlay").css("visibility", "visible").css("opacity", "1");  

    });

    $('#tabChoise').on('dblclick','.tbl_row', function(){ // SELECIONANDO UM ÍTEM DA TABELA (DUPLO CLIQUE)
        var arr = window.location.href.split("/");

        if(arr[arr.length-1] == 'cad_item_ped.php#' || arr[arr.length-1] == 'cad_item_ped.php'){ // CAD ITEM PED - TAB 1
            $('[name="cod_prod"]').val($.trim($(this).children('td').slice(0, 1).text().toUpperCase()));
            $('[name="qtd"]').val($.trim($(this).children('td').slice(3, 4).text().toUpperCase()));
            $('[name="preco"]').val($(this).moeda($.trim($(this).children('td').slice(4, 5).text().toUpperCase())));
           
            $(document).off('keyup', '#edtEdtQtd').on('keyup', '#edtEdtQtd', function() { // VALIDA OS FORMULARIOS 
                txt = $('#edtEdtQtd').val()
                $("#edtEdtQtd").val($(this).numeros(txt));
            }); 

             $(document).off('keyup', '#edtEdtPreco').on('keyup', '#edtEdtPreco', function() { // VALIDA OS FORMULÁRIOS
                txt = $('#edtEdtPreco').val()
                $("#edtEdtPreco").val($(this).moeda(txt));
            }); 
        }

        if(arr[arr.length-1] == 'cad_item_ent.php#' || arr[arr.length-1] == 'cad_item_ent.php'){ // CAD ITEM PED - TAB 1
            $('[name="cod_prod"]').val($.trim($(this).children('td').slice(0, 1).text().toUpperCase()));
            $('[name="qtd"]').val($.trim($(this).children('td').slice(3, 4).text().toUpperCase()));
            $('[name="preco"]').val($(this).moeda($.trim($(this).children('td').slice(4, 5).text().toUpperCase())));
           
            $(document).off('keyup', '#edtEdtQtd').on('keyup', '#edtEdtQtd', function() { // VALIDA OS FORMULARIOS 
                txt = $('#edtEdtQtd').val()
                $("#edtEdtQtd").val($(this).numeros(txt));
            }); 

             $(document).off('keyup', '#edtEdtPreco').on('keyup', '#edtEdtPreco', function() { // VALIDA OS FORMULÁRIOS
                txt = $('#edtEdtPreco').val()
                $("#edtEdtPreco").val($(this).moeda(txt));
            }); 
        }        

    });


});

// VALIDAÇÕES

$.fn.numeros = function(param){ // RECEBE UMA STRING E LIMPA TD QUE NÃO FOR NUMERO DELA
    var pos = ['1','2','3','4','5','6','7','8','9','0'];
    var out = '';
    for(i=0;i<param.length;i++){
        chr = param.substring(i,i+1);
        if(jQuery.inArray(chr,pos) != -1){
            out = out + chr;
        }
    }
    return out;
}

$.fn.moeda = function(param){ // RECEBE UMA STRING E LIMPA TD QUE NÃO FOR NUMERO DELA, só deixa 2 casa depois da virgula
    var pos = ['1','2','3','4','5','6','7','8','9','0'];
    var out = '';
    var aft = 0;

    for(i=0;i<param.length;i++){
        chr = param.substring(i,i+1);

        if((chr == ',' || chr == '.') && aft == 0){ // coloca o ponto e começa a contar as casas
            out = out + '.';
            aft++;

        }

        if(jQuery.inArray(chr,pos) != -1 && aft < 3){
            out = out + chr;
            if(aft > 0){
                aft++;
            }
        }       
    }
    return out;
}
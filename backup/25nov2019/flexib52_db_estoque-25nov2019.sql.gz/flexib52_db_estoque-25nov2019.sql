-- MySQL dump 10.16  Distrib 10.1.41-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 108.179.253.230    Database: flexib52_db_estoque
-- ------------------------------------------------------
-- Server version	5.6.41-84.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_agenda`
--

DROP TABLE IF EXISTS `tb_agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emp` int(11) NOT NULL,
  `nome` varchar(40) NOT NULL,
  `email` varchar(70) DEFAULT NULL,
  `depart` varchar(15) DEFAULT NULL,
  `cel1` varchar(14) DEFAULT NULL,
  `cel2` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_agenda`
--

LOCK TABLES `tb_agenda` WRITE;
/*!40000 ALTER TABLE `tb_agenda` DISABLE KEYS */;
INSERT INTO `tb_agenda` VALUES (1,16,'Agnaldo ','agnaldo10tintas@gmail.com ','vendas ','(12)99854-5636',' '),(2,37,'Tales Cembraneli Dantas','tales@flexibus.com.br','Engenharia','(12)9 9711 379','');
/*!40000 ALTER TABLE `tb_agenda` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_empresa`
--

DROP TABLE IF EXISTS `tb_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_empresa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(50) NOT NULL,
  `cnpj` varchar(14) DEFAULT NULL,
  `ie` varchar(14) DEFAULT NULL,
  `endereco` varchar(60) DEFAULT NULL,
  `cidade` varchar(30) DEFAULT NULL,
  `estado` varchar(2) DEFAULT NULL,
  `tipo` varchar(3) DEFAULT NULL,
  `tel` varchar(14) DEFAULT NULL,
  `cep` varchar(10) DEFAULT NULL,
  `class` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_empresa`
--

LOCK TABLES `tb_empresa` WRITE;
/*!40000 ALTER TABLE `tb_empresa` DISABLE KEYS */;
INSERT INTO `tb_empresa` VALUES (16,'farben s/a industria quimica ','85111441000385','336564779116 ','av. amancio gaioli, 725 bairro agua chata ','guarulhos ','SC','FOR','(11)2088-9200 ','07.251-250',NULL),(13,'Flexibus (Fabricacao propria) ','00519547000106',' ','Rua dr. Rosalvo de Almeida Telles, 2070 ','Cacapava ','SP','FOR','(12)3653-2230 ','12283-020 ',NULL),(14,'viacao jacarei  ','4456325411112 ','  ','Rua teste de rua, 36  ','jacarei ','SP','CLI','  ','14.568-856',NULL),(15,'maxi rubber industria quimica ltda ','00283822000470','286391325110 ','av. luiz merenda, 659 ','diadema ','SP','FOR','(11)4092-7777 ','99.931-390',NULL),(17,'vip imperador','12','2112212','12','12','SP','CLI','1222111221','121212',NULL),(18,'allfra comercial ltda ','17353313000126','796138627113 ','avenida torres tibagy ,690 -vila aprazivel  ','guarulhos ','SP','FOR','(11) 22033703 ','0706200 ',NULL),(19,'VANDERLEI RODRIGUES MANUTENCAO INDUSTRIAL ME  ','2465059900177 ','  ','RUA PRES. JUSCELINO KUBITSCHEK OLIVEIRA,122-JD MARIA CANDIDA','CAÇAPAVA ','SP','FOR','3653-5643  ','12.284-280',NULL),(20,'OUTROS','','','','','SP','FOR','','',NULL),(21,'ALMEIDAS USINAGEM','','','','','SP','FOR','','',NULL),(22,'DORIVALE PAPELARIA','','','','','SP','FOR','','',NULL),(23,'IMPERIAL TINTAS','','','','','SP','FOR','','',NULL),(24,'ROCAR','','','','','SP','FOR','','',NULL),(25,'CASA DE FERRAGENS','','','','','SP','FOR','','',NULL),(26,'SURIANA','','','','','SP','FOR','','',NULL),(27,'SALES DISTRIBUIDORA','','','','','SP','FOR','','',NULL),(28,'QUARIS','','','','','SP','FOR','','',NULL),(29,'LG GRAMPIADORES','','','','','SP','FOR','','',NULL),(30,'REIS E REIS','','','','','SP','FOR','','',NULL),(31,'FCC ','','','','','SP','FOR','','',NULL),(32,'WS FROTAMIX','','','','','SP','FOR','','',NULL),(33,'BOSS BRASIL','','','','','SP','FOR','','',NULL),(34,'ABRAFIX PARAFUSO','','','','','SP','FOR','','',NULL),(35,'Linhasita','','','','','SP','FOR','','',NULL),(36,'Casa do parafuso','','','','','SP','FOR','','',NULL),(37,'FLEXIBUS SANFONADOS','00519547000106','234033845113','AV. DR. ROSALVO DE ALMEIDA TELLES,270 NOVA CPV','CACAPAVA','SP','CLI','12-36532230','12283-020',NULL),(38,'CISER PARAFUSO','','','','','SP','FOR','','',NULL),(39,'Liart','','','','','SP','FOR','','',NULL),(40,'VINIFLEX','','','','','SP','FOR','','',NULL),(41,'bandeirantes quimica','','','','','SP','FOR','','',NULL),(42,'MOBIBRASIL TRANSPORTE SAO PAULO LTDA','11031202000117','','ESTRADA DO ALVARENGA, 4000 A-BALNEARIO SAO FRANCISCO','SAO PAULO','SP','CLI','','04474-340',NULL),(43,'Empresa de Transporte Sao Judas Tadeu   ',' 843025000156 ','0100068400167 ','Rodovia BR 364, KM 05, numero 8317-Distrito industrial   ','rio branco    ','AC','CLI',' 75 8315-2262 ','69.920-223',NULL);
/*!40000 ALTER TABLE `tb_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_entrada`
--

DROP TABLE IF EXISTS `tb_entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_entrada` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nf` varchar(10) DEFAULT NULL,
  `id_emp` int(11) NOT NULL,
  `data_ent` date DEFAULT NULL,
  `resp` varchar(15) DEFAULT NULL,
  `status` varchar(7) NOT NULL DEFAULT 'ABERTO',
  PRIMARY KEY (`id`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_entrada`
--

LOCK TABLES `tb_entrada` WRITE;
/*!40000 ALTER TABLE `tb_entrada` DISABLE KEYS */;
INSERT INTO `tb_entrada` VALUES (9,'fab.',13,'2019-11-22','tania','FECHADO');
/*!40000 ALTER TABLE `tb_entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_item_compra`
--

DROP TABLE IF EXISTS `tb_item_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_item_compra` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prod` int(11) NOT NULL,
  `id_ent` int(11) DEFAULT NULL,
  `qtd` double NOT NULL DEFAULT '0',
  `preco` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_prod` (`id_prod`),
  KEY `id_ent` (`id_ent`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_item_compra`
--

LOCK TABLES `tb_item_compra` WRITE;
/*!40000 ALTER TABLE `tb_item_compra` DISABLE KEYS */;
INSERT INTO `tb_item_compra` VALUES (18,141,9,2,920),(15,142,9,80,100);
/*!40000 ALTER TABLE `tb_item_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_item_ped`
--

DROP TABLE IF EXISTS `tb_item_ped`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_item_ped` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_prod` int(11) NOT NULL,
  `id_ped` int(11) DEFAULT NULL,
  `qtd` double NOT NULL DEFAULT '0',
  `preco` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `id_prod` (`id_prod`),
  KEY `id_ped` (`id_ped`)
) ENGINE=MyISAM AUTO_INCREMENT=97 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_item_ped`
--

LOCK TABLES `tb_item_ped` WRITE;
/*!40000 ALTER TABLE `tb_item_ped` DISABLE KEYS */;
INSERT INTO `tb_item_ped` VALUES (59,142,13,80,100),(58,148,13,40,80),(57,141,13,2,920),(56,153,13,1,13.85),(55,165,13,3,1.98),(54,169,13,1,55.15),(53,168,13,1,166.88),(52,166,13,7,0.6),(51,167,13,2,1.2),(50,153,13,1,13.85),(49,158,13,1,4),(48,156,13,2,1.9),(47,160,13,1,12),(60,170,13,300,0.05),(94,141,18,6,920),(93,150,16,2,150);
/*!40000 ALTER TABLE `tb_item_ped` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_pedido`
--

DROP TABLE IF EXISTS `tb_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_pedido` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emp` int(11) NOT NULL,
  `data_ped` date DEFAULT NULL,
  `data_ent` date DEFAULT NULL,
  `resp` varchar(15) DEFAULT NULL,
  `comp` varchar(30) DEFAULT NULL,
  `num_ped` varchar(15) DEFAULT NULL,
  `status` varchar(7) NOT NULL DEFAULT 'ABERTO',
  `nf` varchar(10) DEFAULT NULL,
  `desconto` double NOT NULL DEFAULT '0',
  `cond_pgto` varchar(100) DEFAULT '28 d.d.d',
  `obs` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_pedido`
--

LOCK TABLES `tb_pedido` WRITE;
/*!40000 ALTER TABLE `tb_pedido` DISABLE KEYS */;
INSERT INTO `tb_pedido` VALUES (13,37,'2019-11-22','2019-11-22','TANIA ','TANIA ','191122-0 ','FECHADO',NULL,0,'28 d. ',' '),(16,42,'2019-11-22','0000-00-00','TANIA     ','ALISSON     ','5729184     ','ABERTO',NULL,0,'28 ddd ','(fob) '),(18,43,'2019-11-22','0000-00-00','tania ','marcos ','191122-2 ','ABERTO',NULL,0,'28 d.d.d ','frete fob ');
/*!40000 ALTER TABLE `tb_pedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_produto`
--

DROP TABLE IF EXISTS `tb_produto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_produto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emp` int(11) NOT NULL,
  `descricao` varchar(80) NOT NULL,
  `estoque` double NOT NULL DEFAULT '0',
  `etq_min` double NOT NULL DEFAULT '0',
  `unidade` varchar(10) DEFAULT NULL,
  `ncm` varchar(8) DEFAULT NULL,
  `cod` varchar(15) NOT NULL,
  `cod_bar` varchar(15) DEFAULT NULL,
  `reserva` double NOT NULL DEFAULT '0',
  `preco_comp` double NOT NULL DEFAULT '0',
  `margem` double NOT NULL DEFAULT '40',
  PRIMARY KEY (`id`),
  UNIQUE KEY `cod` (`cod`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=200 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_produto`
--

LOCK TABLES `tb_produto` WRITE;
/*!40000 ALTER TABLE `tb_produto` DISABLE KEYS */;
INSERT INTO `tb_produto` VALUES (25,18,'DISCO DE LIXA P 320  ',150,4,'UNID\r\n ','68051000','1077    ','063    ',0,1.27,40),(4,0,'',0,0,'','','','',0,0,40),(7,18,'PAPEL SEMI KRAFT 60GRS 45CM D10 1,5KG   ',30,10,'ROLO\r\n ','48025592','1062   ','008   ',0,13.9,40),(8,18,'PAPEL SEMI KRAFT 60GRS 90CM D10 3KG      ',20,10,'ROLO\r\n ','48025592','1063      ','009      ',0,7.15,40),(9,18,'ESPATULA FLEXIVEL PARA APLICACAO DE MASSAS   ',30,10,'PECA\r\n ','82055900','1064   ','085   ',0,1.18,40),(10,18,'ESTOPA PARA POLIMENTO ALLFRA 400G 100% ALGODÃƒO  ',120,40,'PACOTE\r\n ','52029900','1065  ','251  ',0,3.43,40),(11,18,'FITA CREPE AUTOMOTIVA AMARELA 18X40 -adere ',64,30,'ROLO\r\n ','48114110','1066   ','305   ',0,2.81,40),(12,18,'FITA CREPE USO GERAL BRANCA 24X50 ',60,30,'ROLO\r\n ','48114110','1067   ','307   ',0,2.82,40),(13,18,'FITA CREPE USO GERAL BRANCA 48X50- ADERE ',72,30,'ROLO\r\n ','48114110','1068   ','306   ',0,5.63,40),(14,18,'COADOR DESCARTAVEL   ',300,50,'UNID\r\n ','96040000','1069   ','086   ',0,0.55,40),(15,18,'SUPORTE PARA LIXADEIRA ROTO ORBITAL HOOKIT 6  ',5,5,'UNID\r\n ','84669200','1070  ','057  ',0,25.97,40),(16,18,'SUPORTE PARA LIXADEIRA ROTO ORBITAL HOOKIT 5Â´   ',5,5,'UNID\r\n ','84669200','1071   ','058   ',0,24.5,40),(17,18,'DISCO DE LIXA P40 - PACOTE CONTEM 25 PECAS   ',4,4,'PACOTE\r\n ','68051000','1072   ','059   ',0,31.77,40),(18,18,'DISCO DE LIXA P80 - PACOTE CONTEM 25 PECAS   ',8,4,'PACOTE\r\n ','68051000','1073   ','060   ',0,31.77,40),(19,18,'DISCO DE LIXA P120 - PACOTE CONTEM 25 PECAS   ',4,4,'PACOTE\r\n ','68051000','1074   ','214   ',0,31.77,40),(20,18,'DISCO DE LIXA P150 - PACOTE CONTEM 25 PECAS   ',4,4,'PACOTE\r\n ','68051000','1075   ','061   ',0,31.77,40),(21,18,'DISCO DE LIXA P220 - PACOTE CONTEM 25 PECAS   ',8,4,'PACOTE\r\n ','68051000','1076   ','062   ',0,31.77,40),(22,18,'DISCO DE LIXA P600 - PACOTE CONTEM 25 PECAS  ',1,4,'PACOTE\r\n ','68051000','1078  ','065  ',0,31.77,40),(23,18,'DISCO DE LIXA P800 - PACOTE CONTEM 25 PECAS   ',1,4,'PACOTE\r\n ','68051000','1079   ','066   ',0,31.77,40),(24,18,'ALL LUB ANTI CORROSIVO COLORART     ',20,10,'LATA\r\n ','38249941','1080     ','275     ',0,5.25,20),(27,16,'thinner 5000 -18 lt     ',4,4,'UNID\r\n ','38140090','1081   ','555.000-018    ',0,126.15,40),(28,16,'thinner 5000 -5 lt  ',8,5,'LATA\r\n ','38140090','1082   ','555.000-5.0   ',0,36.88,40),(29,16,'THINNER PU 8000 -900 ml ',60,30,'LATA\r\n ','38140090','1083 ','558.000-0.9 ',0,8.18,40),(30,16,'THINNER PU 8000 - 18 lt  ',2,5,'GALAO\r\n ','38140090','1084   ','558.000-018   ',0,145.23,40),(31,16,'THINNER PU 8000 -5 lt  ',8,5,'GALAO\r\n ','38140090','1085  ','558.000-5.0  ',0,41.45,40),(32,16,'ENDURECEDOR P/ ESM.PU ACR.-900 ml ',65,50,'LATA\r\n ','38249931','1086  ','573.790-0.9  ',0,29.45,40),(34,15,'MASSA DE POLIESTER 750G ',12,20,'LATA\r\n ','32141010','1088 ','1MG018 ',2,14.37,40),(35,15,'MASSA DE POLIESTER 1,5 KG ',12,20,'LATA\r\n ','32141010','1089 ','1MG024 ',0,27.61,40),(36,15,'MASSA DE POLIESTER 1KG ',12,15,'LATA\r\n ','32141010','1090 ','1MG028 ',0,18.75,40),(37,15,'MASSA DE POLIESTER C/ FIBRA- 750 g -c/ catalisador ',12,20,'LATA\r\n ','32141010','1091 ','1MG051 ',0,21.06,40),(38,15,'MASSA RaPIDA CINZA 1,25 KG  ',12,15,'LATA\r\n ','32141020','1092  ','2MA001  ',0,17.18,40),(39,15,'MASSA RaPIDA PREMIUM-620 G  ',12,12,'LATA\r\n ','32141020','1093  ','2MA006  ',0,11.01,40),(40,15,'PRIMER UNIVERSAL -900 ml ',12,15,'LATA\r\n ','32089010','1094  ','2MA015  ',0,15.92,40),(41,15,'MASSA RaPIDA BRANCA 1,25 KG  ',12,15,'LATA\r\n ','32141020','1095  ','2MA085  ',0,18.51,40),(42,15,'PRIMER HS PU 411-900 ml ',6,10,'LATA\r\n ','32081010','1096 ','2MG002 ',0,14.49,40),(43,15,'PRIMER HS 511- 750 ml ',6,6,'LATA\r\n ','32081010','1097 ','2MG010 ',1,12.49,40),(44,15,'PRIMER HS PU 611 PRETO -900 ml ',6,10,'LATA\r\n ','32081010','1098 ','2MG015 ',0,18.57,40),(45,15,'REMOVEDOR PASTOSO 1,0 KG ',12,12,'LATA\r\n ','38140090','1099 ','2MS001 ',0,16.06,40),(46,15,'WHASH PRIMER - 600ML ',6,10,'LATA\r\n ','32082019','1100 ','3MA001 ',0,13.83,40),(47,15,'PRETO FOSCO VINILICO - 600ML ',6,6,'LATA\r\n ','32082019','1101 ','3MA011 ',0,14.7,40),(48,15,'SELADORA PARA PLASTICO -900ML ',6,6,'LATA\r\n ','32089039','1102 ','4MP006 ',0,22.61,40),(50,15,'MASSA DE POLIR 1 - 980 G ',12,15,'LATA\r\n ','34053000','1103 ','6mh001 ',0,16.77,40),(51,15,'MASSA DE POLIR 2 - 970 G ',12,12,'LATA\r\n ','34053000','1104 ','6mh010 ',0,16.92,40),(52,15,'COLA UNIVERSAL -774 G ',12,15,'LATA\r\n ','35069110','1105 ','7ma061 ',0,18.19,40),(53,15,'SOLUCAO DESENGRAXANTE- 900ML  ',12,20,'LATA\r\n ','29012900','1106  ','7MP012  ',0,9.95,40),(54,15,'MAXI MANTA 1,40 X 0,50 M ',12,12,'PECA\r\n ','70193100','1107 ','8MP046 ',0,9.57,40),(55,15,'MAXI BOINA DUPLA FACE BRANCA  ',4,4,'PECA\r\n ','9603500 ','1108  ','8MP048  ',0,75.9,40),(56,15,'MAXI BOINA DUPLA FACE AMARELA  ',4,4,'PECA\r\n ','9603500 ','1109  ','8MP050  ',0,75.9,40),(57,15,'PANO POLIMENTO MICRO FIBRA    ',12,12,'UNID\r\n ','63071000','1110    ','8MP056    ',0,8.74,40),(58,15,'CATALISADOR . WASH/PRETO FOSCO -300 ML ',12,12,'LATA\r\n ','38249939','1111 ','9MB009 ',0,6.03,40),(59,15,'CATALISADOR  PRIMER PU 511 -150 ML ',6,6,'LATA\r\n ','38249931','1112 ','9MB021 ',0,7.08,40),(60,15,'CATALISADOR  PRIMER PU 411 -225 ML ',6,6,'LATA\r\n ','38249931','1113 ','9MB022 ',0,11.15,40),(61,15,'CATALISADOR  PRIME PU 611 -150 ML ',6,6,'LATA\r\n ','38249931','1114 ','9MB037 ',0,9.03,40),(68,16,'solucao flexibilizante-900 ml ',6,12,'LATA\r\n ','32081010','1117 ','509.080-0.9 ',0,46.25,40),(69,16,'lata 900 ml linha frota - vasilhame ',112,100,'LATA\r\n ','73102190','1115 ','005.144 ',0,4.12,40),(70,16,'galao linha frota tintometrica- 3,6 ml-vasilhame ',60,100,'LATA\r\n ','73102990','1116 ','0005.184 ',0,10.58,40),(72,16,'conc.violeta rl- pigmento 900 ml   ',2,2,'LATA\r\n ','32129090','1118   ','ac135-0.9   ',0,113.62,0),(73,16,'conc.vermelho vivo-pigmento -900 ml  ',2,2,'LATA\r\n ','32129090','1119  ','ac135-0.9  ',0,70.51,0),(74,16,'conc.alquidico branco- pigmento -3.6 ml  ',1,1,'PECA\r\n ','32129090','1120  ','ac171-3.6  ',0,142.56,0),(75,16,'conc.amarelo ouro-pigmento -900 ml   ',1,1,'LATA\r\n ','32129090','1121   ','ac172-9.0   ',0,55.78,0),(76,16,'conc.amarelo limÃ£o - pigmento 900 ml  ',1,1,'LATA\r\n ','32129090','1122  ','ac173-9.0  ',0,52.76,0),(77,16,'conc.amarelo oxido-pigmento-900 ml  ',1,1,'LATA\r\n ','32129090','1123  ','ac174-0.9  ',0,31.08,0),(78,16,'conc.laranja-pigmento -900 ml  ',1,1,'LATA\r\n ','32129090','1124  ','ac175-0.9  ',0,100.88,0),(79,16,'conc.vermelho oxido-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090','1125  ','ac176-0.9  ',0,34.67,0),(80,16,'conc.azul-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090','1126  ','ac177-0.9  ',0,42.6,0),(81,16,'conc. verde- pigmento 900 ml  ',1,1,'LATA\r\n ','32129090','1127  ','ac178-0.9  ',0,43.29,0),(82,16,'conc.vermelho pleno -pigmento 900 ml  ',1,1,'LATA\r\n ','32129090','1128  ','ac179-0.9  ',0,45.6,0),(167,27,'SABAO EM PEDRA',82,30,'UNID\r\n','00000000','176','176',0,1.2,0),(83,16,'conc.preto-pigmento 900 ml  ',2,1,'LATA\r\n ','32129090','1129  ','ac180-0.9  ',0,26.39,0),(85,16,'conc.amarelo limÃ£o organico-pigmento 900 ml   ',1,1,'LATA\r\n ','32129090','1130   ','ac183-0.9   ',0,63.36,0),(86,16,'conc. laranja organico -pigmento 900 ml   ',1,1,'LATA\r\n ','32129090','1131   ','ac185-0.9   ',0,62.18,0),(87,16,'conc.vinho oxido-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090','1132  ','ac186-0.9  ',0,57.41,0),(88,16,'conc.vermelho avioletado-pigmento 900 ml  ',1,1,'LATA\r\n ','32129090','1133  ','ac279-0.9  ',0,122.31,0),(89,16,'CONC.preto azulado-pigmento 900 ml  ',2,1,'LATA\r\n ','32129090','1134  ','AC280-0.9  ',0,65.36,0),(90,16,'base sint.branco -PIGMENTO 3.6 ml  ',8,8,'GALAO\r\n ','32081010','1135  ','aes40-3.6  ',0,74.28,0),(91,16,'clear sint.-PIGMENTO 3.6 ML ',8,5,'PECA\r\n ','32081020','1136 ','AES45-3.6 ',0,63.41,0),(92,16,'base nc branca automotiva- pigmento 3.6 ml ',8,8,'PECA\r\n ','32089021','1137 ','anc55-3.6 ',0,104.99,0),(93,16,'clear nc automotivo-pigmento 3.6 ml ',8,8,'PECA\r\n ','32089021','1138 ','anc55-3.6 ',0,91.07,0),(94,16,'base pu acr.incolor- pigmento 3.6 ml ',12,12,'GALAO\r\n ','32081020','1139 ','apa85-3.6 ',0,96.67,0),(95,16,'base  poliester incolor-pigmento 18 lt ',1,1,'GALAO\r\n ','32081020','1140 ','ape75-018 ',0,302.41,0),(96,16,'base pu branca frota-pigmento 3.6 ml ',8,8,'GALAO\r\n ','32081010','1141 ','apu60-3.6 ',0,125.11,0),(168,32,'TINTA CINZA PARA SANFONA -3.6 ML',3,5,'GALAO\r\n','32081010','183','183',0,166.88,0),(97,16,'clear pu frota- PIGMENTO 3.6 ML ',8,8,'GALAO\r\n ','32081020','1142 ','APU65-3.6 ',0,102.97,0),(98,16,'CONC. UNIVERSAL VIOLETA-PIGMENTO 900 ML',1,1,'LATA\r\n','21129090','1143','UC221-0.9',0,131.31,0),(99,16,'CONC. AMARELO ALARANJADO UNIVERSAL- PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1144','UC262-0.9',0,271.01,0),(100,16,'CONC. UNIVERSAL CASTANHO TRANSP.-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1145','UC266-0.9',0,161.28,0),(101,16,'CONC. UNIVERSAL VERMELHO SCARLAT TRANSP. -PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1146','UC268-0.9',0,248.75,0),(102,16,'CONC. UNIVERSAL PRETO INTENSO-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1147','UC270-0.9',0,59.52,0),(103,16,'CONC. UNIVERSAL BRANCO TRANSP.- PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1148','UC271-0.9',0,373.41,0),(104,16,'CONC. UNIVERSAL VERMELHO AZULADO-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1149','UC274-0.9',0,218.81,0),(105,16,'CONC. UNIVERSAL ROSA-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1150','UC275-0.9',0,100.91,0),(106,16,'CONC. UNIVERSAL MARROM TRANSP.-PIGMENTO 900 ML',1,1,'LATA\r\n','32129090','1151','UC276-0.9',0,99.84,0),(107,16,'conc. universal azul avermelhado-pigmento 900 ml ',1,1,'LATA\r\n ','32129090','1152 ','uc277-0.9 ',0,139.35,0),(108,16,'conc. amarelo esverdeado transp.-pigmento 900 ml',1,1,'LATA\r\n','32129090','1153','uc278-0.9',0,299.6,0),(109,16,'conc. universal vermelho avioletado-pigmento 900 ml',1,1,'LATA\r\n','32129090','1154','uc279-0.9',0,102.18,0),(110,16,'conc. universal preto azulado-pigmento 900 ml',1,1,'LATA\r\n','32129090','1155','uc280-0.9',0,49.67,0),(111,16,'conc. universal branco-pigmento 3.6 ml ',1,1,'GALAO\r\n ','32129090','1156 ','uc281-3.6 ',0,216.11,0),(112,16,'conc. universal amarelo ouro-pigmento 900 ml',1,1,'LATA\r\n','32129090','1157','uc282-0.9',0,94.67,0),(113,16,'conc. universal amarelo limAo-pigmento 3.6 ml ',1,1,'GALAO\r\n ','32129090','1158 ','uc283-3.6 ',0,331.2,0),(114,16,'conc. universal amarelo oxido-pigmento 900 ml',1,1,'LATA\r\n','32129090','1159','uc284-0.9',0,47.76,0),(115,16,'conc. universal laranja-pigmento 900 ml',1,1,'LATA\r\n','32129090','1160','uc285-0.9',0,146.9,0),(116,16,'conc. universal vermelho oxido-pigmento 900 ml',1,1,'LATA\r\n','32129090','1161','uc286-0.9',0,44.03,0),(117,16,'conc. universal azul - pigmento 900 ML',1,1,'LATA\r\n','32129090','1162','uc287-0.9',0,49.28,0),(118,16,'conc. universal verde-pigmento 900 ml',1,1,'LATA\r\n','32129090','1163','uc288-0.9',0,53.13,0),(119,16,'conc. universal vermelho pleno-pigmento -900 ml',1,1,'LATA\r\n','31129090','1164','uc289-0.9',0,48.75,0),(120,16,'conc. universal preto-pigmento 3.6 ml  ',1,1,'GALAO\r\n ','32129090','1165  ','uc290-3.6  ',0,203.34,0),(121,16,'conc. universal vermelho limpo-pigmento 900 ml',1,1,'LATA\r\n','32129090','1166','uc291-0.9',0,65.52,0),(122,16,'conc. universal amarelo transp. pigmento 900 ml',1,1,'LATA\r\n','31129090','1167','uc294-0.9',0,61.61,0),(123,16,'conc. universal vermelho transp.- pigmento 900 ml',1,1,'LATA\r\n','32129090','1168','uc296-0.9',0,50.09,0),(124,16,'conc. universal azul esverdeado- pigmento 900 ml',1,1,'LATA\r\n','32129090','1169','uc297-0.9',0,54.27,0),(125,16,'conc. universal azul escuro-pigmento 900 ml',1,1,'LATA\r\n','32129090','1170','uc298-0.9',0,87.68,0),(126,16,'conc.fosqueante universal- pigmento 3.6 ml ',1,1,'GALAO\r\n ','32129090','1171 ','uc525-3.6 ',0,148.8,0),(127,16,'soluCAo para ajuste metAlico -pigmento 900 ml ',1,1,'LATA\r\n ','32129090','1172 ','uc580-0.9 ',0,42.37,0),(128,16,'conc. aluminio medio brilhante-pigmento 900 ml ',1,1,'LATA\r\n ','32129090','1173 ','uc643-0.9 ',0,198.34,0),(129,16,'conc. aluminio graudo 900 ml ',1,1,'LATA\r\n ','32129090','1174 ','uc645-0.9 ',0,81.61,0),(130,16,'conc. aluminio super fino -pigmento 900 ML ',1,1,'LATA\r\n ','32129090','1175 ','uc648-0.9 ',0,96.23,0),(131,16,'conc. aluminio fino-pigmento 900 ml ',1,1,'LATA\r\n ','32129090','1176 ','uc650-0.9 ',0,65.67,0),(132,16,'conc. de aluminio medio-pigmento 900 ml ',1,1,'LATA\r\n ','32129090','1177 ','uc655-0.9 ',0,69.13,0),(133,16,'conc. aluminio super graudo',1,1,'LATA\r\n','32129090','1178','uc675-0.9',0,147.17,0),(134,16,'conc. aluminio brilhante -pigmento 900 ml',1,1,'LATA\r\n','32129090','1179','uc680-0.9',0,102.3,0),(135,16,'conc. aluminio medio limpo-pigmento 900 ml ',1,1,'LATA\r\n ','32129090','1180 ','uc685-0.9 ',0,61.18,0),(136,16,'thinner para base poliester 9700- para  pigmento 18 lt  ',1,1,'GALAO\r\n ','38140090','1181  ','uc700-018  ',0,239.76,0),(137,13,'BARRA DE ALUMINIO DE PORTICO (1,80 mt)  ',2,2,'PECA\r\n ','87082999','101 ','101 ',0,400,0),(138,13,'BARRA DE ALUMiNIO PERFIL 7 X16 (735 MM) ',15,10,'PECA\r\n ','87082999','102 ','102 ',0,50,0),(139,13,'BARRA DE PORTICO CENTRAL - 180 -1,60 -1,40 MT',14,6,'PECA\r\n','87082999','103','103',0,750,0),(140,13,'CABO DE AcO (3/16) COM CLIPS-11 MTS ',100,200,'PECA\r\n ','87082999','105 ','105 ',0,172,0),(141,13,'CHAO SANF.  ONIBUS COMPl. C/ VARETA  ',23,6,'PAR\r\n ','89082999','107  ','107  ',0,920,0),(142,13,'CURVA DE ALUMINIO (teto OU  chAo)',295,50,'PECA\r\n','87082999','108','108',0,100,0),(143,13,'ESTICADOR  DE CABO DE AcO  ',34,20,'PECA\r\n ','89082999','110 ','110 ',0,57.5,0),(144,13,'HASTE TELESCOPICA',3,6,'PECA\r\n','87082999','111','111',0,517,0),(145,19,'PINO REI ',4,5,'PECA\r\n ','87082999','121 ','121 ',0,375,60),(146,13,'PISO DE BORRACHA',8,5,'PECA\r\n','87082999','122','122',0,100,0),(147,13,'CLIPS -PRESILHA CABO DE AÃ‡O (3/16)',108,200,'PECA\r\n','87082999','123','123',0,1.2,0),(148,13,'VARETA DE CHaO DE SANFONA ',140,50,'PECA\r\n ','87082999','127 ','127 ',0,80,0),(149,13,'ZIPER  DA SANFONINHA INTERNA ',43,10,'PECA\r\n','87082999','128','128',0,200,0),(150,13,'PERFIL DE BORRACHA PARA SUSPENSAO(9 MT)  ',12,1,'ROLO\r\n ','87082999','129  ','129  ',0,160,0),(151,13,'TERMINAL ESFERICO-cabeÃ§a da Haste',26,20,'PECA\r\n','87082999','139','139',0,45,0),(152,13,'CALAFETADOR (bisnaga) - MS 40',24,12,'PECA\r\n','87082999','140','140',0,15,0),(153,13,'COLA PVC -SANFONA',39,50,'LATA\r\n','87082999','142','142',0,13.85,0),(154,13,'CONDUITE PRETO EM ROLOS 100 MTS',3,1,'ROLO\r\n','87082999','143','143',0,950,0),(155,13,'CURSOR DE ZIPER',80,30,'PECA\r\n','87082999','144','144',0,0.6,0),(156,13,'ESTOPA - 200 GR',106,50,'PACOTE\r\n','87082999','145','145',0,1.9,0),(157,13,'FECHO PARA CHAO  DE SANFONA',200,50,'PECA\r\n','87082999','146','146',0,3,0),(158,22,'FITA ADESIVA (EMBALAR) ',2,10,'ROLO\r\n ','87282999','147 ','147 ',0,4,0),(159,29,'GRAMPO 73/8  ',2,2,'CAIXA\r\n ','87082999','148 ','148 ',0,12,0),(160,29,'GRAMPO 23/8 ',15,5,'CAIXA\r\n ','87082999','149 ','149 ',0,12,0),(161,29,'GRAMPO 24/8 ',27,5,'CAIXA\r\n ','87082999','150 ','150 ',0,12,0),(162,35,'LINHA BRANCA ',2,1,'ROLO\r\n ','87082999','151 ','151 ',0,8,0),(163,35,'LINHA CINZA ',30,20,'ROLO\r\n ','87082999','152 ','152 ',0,8,0),(164,36,'MOLA PARA HASTE TELESCOPICA ',49,10,'PECA\r\n ','87092999','155 ','155 ',0,3,0),(165,24,'OLEO FINO DE MAQUINA ',19,10,'UNID\r\n ','87082999','157 ','157 ',0,1.98,0),(166,27,'PALHA DE ACO ',196,50,'UNID\r\n ','87082999','158 ','158 ',0,0.6,0),(169,32,'CATALISADOR UNIVERSAL TINTA-900 ML',2,5,'LATA\r\n','32249931','141','141',0,55.15,0),(170,38,'REBITE 4.8 X16  ',1300,1,'PECA\r\n ','00000000','173  ','173  ',0,0.05,0),(171,16,'PAPEL MARROM DE EMBALAR',6,1,'ROLO\r\n','00000000','160','160',0,5,0),(172,38,'PARAFUSO AUTO BROC. 2.5 ',1500,500,'PECA\r\n ','00000000','161 ','161 ',0,0.05,0),(173,38,'PARAFUSO AUTO BROC. 4 CM',50,50,'PECA\r\n','00000000','162','162',0,0.07,0),(174,38,'PARAFUSO CHIP CHATO 4.0X16',2800,500,'PECA\r\n','00000000','163','163',0,0.05,0),(175,34,'parafuso m10x35',80,20,'PECA\r\n','00000000','164','164',0,0.05,0),(176,34,'parafuso m8x20 sextavado',1200,300,'PECA\r\n','00000000','165','165',0,0.05,0),(177,16,'parafuso m8x25 sextavado',500,100,'PECA\r\n','00000000','166','166',0,0.05,0),(178,34,'PARAFUSO com porca m5x20',1200,300,'PECA\r\n','00000000','167','167',0,0.05,0),(179,28,'plastico bolha',7,2,'ROLO\r\n','00000000','168','168',0,35,0),(180,34,'PORCA M10-ESQUERDA ',20,30,'PECA\r\n ','00000000','170 ','170 ',0,3,0),(181,34,'PORCA M10-DIREITA',420,50,'PECA\r\n','00000000','171','171',0,0.5,0),(182,38,'rebite 4.8x35',4000,1000,'PECA\r\n','00000000','172','172',0,0.04,0),(183,39,'resina qualipur 450- 18 lt',2,1,'LATA\r\n','00000','175','175',0,973.05,0),(184,40,'TECIDO FINO-9000',1,3,'ROLO\r\n','00000','178','178',0,2000,0),(185,40,'TECIDO FUNDO PRETO ESP. TOLDO',6,1,'ROLO\r\n','0000000','179','179',0,2000,0),(186,40,'TECIDO GROSSO-12000',7,2,'ROLO\r\n','00000','180','180',0,3000,0),(187,40,'TECIDO FINO PRETO PARA CHAO',1,1,'ROLO\r\n','00000','181','181',0,1000,0),(188,16,'TENSOR BRANCO (ELASTICO)',500,100,'MT\r\n','00000','182','182',0,8,0),(189,23,'TINTA PARA CARIMBO 250 ML',2,1,'LATA\r\n','00000','184','184',0,65,0),(190,26,'VELCRO CRESPO -MACHO',6,5,'ROLO\r\n','0000','185','185',0,32,0),(191,26,'VELCRO LISO-FEMEA',256,10,'ROLO\r\n','000','186','186',0,5,0),(192,26,'ziper em metros',100,50,'MT\r\n','0000000','187','187',0,1.15,0),(193,23,'anti espumante -sanfona',1,1,'LATA\r\n','0000','188','188',0,30,0),(194,26,'argola para sanfoninha',200,50,'PECA\r\n','0000','189','189',0,0.4,0),(195,41,'bansis - solvente 200lt',100,100,'PECA\r\n','0000','190','190',0,1.672,0),(196,24,'barra de sebo para serra',17,5,'PECA\r\n','00000','191','191',0,4.5,0),(197,33,'barra roscada m10',27,10,'PECA\r\n','0000','192','192',0,8,0);
/*!40000 ALTER TABLE `tb_produto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_usuario`
--

DROP TABLE IF EXISTS `tb_usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(12) NOT NULL,
  `pass` varchar(12) NOT NULL,
  `class` int(11) DEFAULT NULL,
  `nome` varchar(40) DEFAULT NULL,
  `email` varchar(70) DEFAULT NULL,
  `cel` varchar(14) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_usuario`
--

LOCK TABLES `tb_usuario` WRITE;
/*!40000 ALTER TABLE `tb_usuario` DISABLE KEYS */;
INSERT INTO `tb_usuario` VALUES (1,'tales','spider ',10,'Tales Cembraneli Dantas    ','tales@flexibus.com.br        ','(12)99711-3793'),(10,'bruno','bruno',2,NULL,NULL,NULL),(9,'tania','123456',4,NULL,NULL,NULL);
/*!40000 ALTER TABLE `tb_usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-25  9:50:12

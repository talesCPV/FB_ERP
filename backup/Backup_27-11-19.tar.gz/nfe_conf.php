<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Configuracoes</title>
    <link rel="stylesheet" type="text/css"  href="css/estilo.css" />
    <script src="js/funcoes.js"></script>
</head>
<body>


  <header>
    <?php
      include "menu.inc";
      $file = "config/nfe.cfg";
      function get_post_action($name)
      {
          $params = func_get_args();

          foreach ($params as $name) {
              if (isset($_POST[$name])) {
                  return $name;
              }
          }
      }

      function make_array($line){
        $val = "";
        $count = 0;
        $resp = [];
        for($i = 0; $i < strlen($line); $i++){
          if(substr($line, $i, 1) == "|"){
            $resp[$count] = $val;
            $val = "";
            $count++;
          }else{
            $val = $val . substr($line, $i, 1);
          }

        }

        return $resp;

      }



  if (file_exists($file)) {
    $fp = fopen($file, "r");
    while (!feof ($fp)) {
      $linha = make_array(fgets($fp,4096)); // Transforma a linha num array
      if (sizeof($linha) > 0){
        switch ($linha[0]) {
          case 'C':
            $xNome = $linha[1];
            $xFant = $linha[2];
            $IE = $linha[3];
            $IEST = $linha[4];
            $IM = $linha[5];
            $CNAE = $linha[6];
            $CRT = $linha[7];
            break;
          case 'C02':
            $CNPJ = $linha[1];
            break;
          case 'C05':
            $xLgr = $linha[1];
            $nro = $linha[2];
            $cpl = $linha[3];
            $bairro = $linha[4];
            $cMun = $linha[5];
            $xMun = $linha[6];
            $UF = $linha[7];
            $CEP = $linha[8];
            $cPais = $linha[9];
            $xPais = $linha[10];
            $fone = $linha[11];
            break;
          default:
              //no action sent
        }
      }
    } 

    fclose($fp);
  }else{

    $xNome = "aa";
    $xFant = "";
    $IE = "";
    $IEST = "";
    $IM = "";
    $CNAE = "";
    $CRT = "";

    $CNPJ = "";

    $xLgr = "";
    $nro = "";
    $cpl = "";
    $bairro = "";
    $cMun = "";
    $xMun = "";
    $UF = "SP";
    $CEP = "";
    $cPais = "1058";
    $xPais = "BRASIL";
    $fone = "";
  }

    ?>
  </header>

<div class="page_container">  
  <div class="page_form">
    <p class="logo"> Configuracao de NFe</p> <br>
    <form class="login-form" name="cadastro" method="POST" action="#" >
      <table>
        <tr>
          <td><button name="emitente" type="submit">Emitente</button></td>
          <td><button name="fiscal" type="submit">Fiscal</button></td>
          <td><button type="submit">*</button></td>
          <td><button type="submit">*</button></td>
          <td><button type="submit">*</button></td>
        </tr>
      </table>
      
    </form>    
  </div>


  <div class="page_form" id="no_margin">

    <?php

      switch (get_post_action('emitente', 'fiscal', 'save_emit')) {
          case 'emitente':
            echo" <p class=\"logo\"> Dados do Emitente</p> <br>";

            echo"
              <form class=\"login-form\" name=\"cadastro\" method=\"POST\" action=\"#\" onsubmit=\"return validaCampo(new Array(cadastro.nome)); return false;\">
                <label> Razão Social *</label>
                <input type=\"text\" name=\"xNome\" maxlength=\"60\" value=\"". $xNome ."\" />
                <label> Nome Fantasia </label>
                <input type=\"text\" name=\"xFant\" maxlength=\"60\" value=\"". $xFant ."\"/>
                <label> Insc. Estadual </label>
                <input type=\"text\" name=\"IE\" maxlength=\"14\" value=\"". $IE ."\" />
                <input type=\"hidden\" name=\"IEST\"  >                
                <label> Insc. Municipal </label>
                <input type=\"text\" name=\"IM\" maxlength=\"15\" value=\"". $IM ."\" />
                <label> CNAE </label>
                <input type=\"text\" name=\"CNAE\" maxlength=\"7\"  value=\"". $CNAE ."\"/>
                <label> Regime Tributário </label>
                <select name=\"CRT\" >
                  <option selected=\"selected\" value=\"1\">Simples Nacional</option>
                  <option value=\"2\">Simples Nacional - excesso de sublimite de receita bruta</option>
                  <option value=\"3\">Regime Normal.</option>
                </select>
                <label> CNPJ </label>
                <input type=\"text\" name=\"CNPJ\" maxlength=\"14\" value=\"". $CNPJ ."\"/>
                <label> Endereço </label>
                <input type=\"text\" name=\"xLgr\" maxlength=\"60\" value=\"". $xLgr ."\" />
                <label> Número: </label>
                <input type=\"text\" name=\"nro\" maxlength=\"5\" value=\"". $nro ."\" />
                <label> Complemento </label>
                <input type=\"text\" name=\"cpl\" maxlength=\"60\"  value=\"". $cpl ."\"/>
                <label> Bairro </label>
                <input type=\"text\" name=\"bairro\" maxlength=\"60\" value=\"". $bairro ."\" />
                <label> Código do Municipio </label>
                <input type=\"text\" name=\"cMun\" maxlength=\"60\" value=\"3508504\" value=\"". $cMun ."\"/>
                <label>  Nome do Municipio</label>
                <input type=\"text\" name=\"xMun\" maxlength=\"60\" value=\"Caçapava\" value=\"". $xMun ."\"/>
                <label> Sigla da UF </label>
                <input type=\"text\" name=\"UF\" maxlength=\"60\" value=\"". $UF ."\" />
                <label> CEP </label>
                <input type=\"text\" name=\"CEP\" maxlength=\"8\" value=\"". $CEP ."\" />
                <label> Código do País  </label>
                <input type=\"text\" name=\"cPais\" maxlength=\"4\" value=\"1058\"value=\"". $cPais ."\" />
                <label> Nome do País </label>
                <input type=\"text\" name=\"xPais\" maxlength=\"60\"  value=\"BRASIL\" value=\"". $xPais ."\"/>
                <label> Telefone </label>
                <input type=\"text\" name=\"fone\" maxlength=\"14\" value=\"". $fone ."\" />
                <td><button name=\"save_emit\" type=\"submit\">SAVE</button></td>

              </form>
            ";
            break;

          case 'fiscal':
            echo" <p class=\"logo\">Fiscal</p> <br>";
            break;
          case 'save_emit':   
            if (IsSet($_POST ["xNome"])){
              $C = "C|".$_POST ["xNome"]."|".$_POST ["xFant"]."|".$_POST ["IE"]."|".$_POST ["IEST"]."|".$_POST ["IM"]."|".$_POST ["CNAE"]."|".$_POST ["CRT"]."|\r\n";
              $C02 = "C02|".$_POST ["CNPJ"]."|\r\n";
              $C05 = "C05|".$_POST ["xLgr"]."|".$_POST ["nro"]."|".$_POST ["cpl"]."|".$_POST ["bairro"]."|".$_POST ["cMun"]."|".$_POST ["xMun"]."|".$_POST ["UF"]."|".$_POST ["CEP"]."|".$_POST ["cPais"]."|".$_POST ["xPais"]."|".$_POST ["fone"]."|\r\n";
              $fp = fopen($file, "a");
              fwrite($fp, $C.$C02.$C05);
              fclose($fp);
            }
            break;

          default:
              //no action sent
        }

    ?>
  </div>

</div>


</body>
</html>
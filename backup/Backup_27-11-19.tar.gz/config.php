<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Configuracoes</title>
    <link rel="stylesheet" type="text/css"  href="css/estilo.css" />
    <script src="js/funcoes.js"></script>
</head>
<body>


  <header>
    <?php
      include "menu.inc";
      if (IsSet($_POST ["memo"]) and $classe >=4 ){
         $texto = $_POST ["memo"];
         $fp = fopen("unidades.txt", "w");
         fwrite($fp, $texto);
         fclose($fp);
      }
      if (IsSet($_POST ["lousa"])){
         $texto = "\n \n".$user." escreveu em ".date('d/m/Y')."\n \n".$_POST ["lousa"];
         $destino = $_POST ["destino"];
         $fp = fopen("lousa/".$destino.".txt", "a");
         fwrite($fp, $texto);
         fclose($fp);
      }

    ?>
  </header>

<div class="page_container">  
  <div class="page_form">
    <p class="logo"> Configuracao</p> <br>
    <form class="login-form" name="cadastro" method="POST" action="#" onsubmit="return validaCampo(); return false;">
      <label> Unidades de Medida </label>
      <textarea name="memo" cols="112" rows="5" ><?php  
          $fp = fopen("unidades.txt", "a+");
          while (!feof ($fp)) {
            $valor = fgets($fp,4096);
            echo $valor;
          }
          fclose($fp);
      echo"</textarea>";

  

      include "conecta_mysql.inc";
      if (!$conexao)
        die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

        $query = "SELECT * from tb_usuario where user != \"".$user."\"";
        $result = mysqli_query($conexao, $query);


        echo"<br><br><label> Lousa de Recados </label>

           <td><select name=\"destino\" >
           <option selected value=\"0\"> Nenhum </option>";


        while($fetch = mysqli_fetch_row($result)){
            echo $fetch[1] . "<br>";
            echo "<option value=\"". $fetch[1] ."\">". $fetch[1] ."</option>";
        }

            echo "</select> </td>";
          $conexao->close();
  
        echo"<textarea name=\"lousa\" cols=\"112\" rows=\"5\" >";

        echo"</textarea>";

      ?>

      <button type="submit">Salvar</button>

    </form>    
  </div>
</div>


</body>
</html>
<?php 
// RECEBENDO OS DADOS PREENCHIDOS DO FORMUL�RIO !
$nome	= $_POST ["nome"];
$forn	= $_POST ["forn"];
$dep	= $_POST ["dep"];
$email	= $_POST ["email"];
$cel	= $_POST ["fone1"];
$fone	= $_POST ["fone2"];

include "conecta_mysql.inc";
if (!$conexao)
	die ("Erro de conex�o com localhost, o seguinte erro ocorreu -> ".mysql_error());



if (IsSet($_POST ["cod_agenda"])){
	$cod_agenda  = $_POST ["cod_agenda"];

	$query = "UPDATE tb_agenda SET  nome = \"". $nome ." \", email = \"". $email ." \", depart = \"". $dep ." \", cel1 = \"". $cel ." \", cel2 = \"". $fone ." \", id_emp = \"". $forn ." \" WHERE id = \"". $cod_agenda ."\" ;";
}else{

	$query = "INSERT INTO tb_agenda ( nome, email, cel1, cel2, id_emp, depart) VALUES ('$nome', '$email', '$cel', '$fone', '$forn', '$dep')";

}


mysqli_query($conexao, $query);
$conexao->close();

setcookie("message", "Contato cadastrado com sucesso!", time()+3600);
header('Location: main.php');

?>
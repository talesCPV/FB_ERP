-- MySQL dump 10.13  Distrib 8.0.19, for Linux (x86_64)
--
-- Host: 108.179.253.230    Database: flexib52_db_estoque
-- ------------------------------------------------------
-- Server version	5.6.41-84.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tb_agenda`
--

DROP TABLE IF EXISTS `tb_agenda`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tb_agenda` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_emp` int(11) NOT NULL,
  `nome` varchar(40) NOT NULL,
  `email` varchar(70) DEFAULT NULL,
  `depart` varchar(15) DEFAULT NULL,
  `cel1` varchar(15) DEFAULT NULL,
  `cel2` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_emp` (`id_emp`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_agenda`
--

LOCK TABLES `tb_agenda` WRITE;
/*!40000 ALTER TABLE `tb_agenda` DISABLE KEYS */;
INSERT INTO `tb_agenda` VALUES (1,16,'AGNALDO','agnaldo10tintas@gmail.com','TINTAS','(12)99854-5636',''),(2,37,'TALES CEMBRANELI DANTAS','tales@flexibus.com.br','ENGENHARIA','(12)99711-3793',''),(4,37,'Tania Cristina Morgado','tania@flexibus.com.br','supervisÃ£o','(12)99799-1867',''),(5,37,'Bruno JosÃ© Mathias','comercial@flexibus.com.br','comercial','(12)99120-2360',''),(6,16,'Sales','salesmartins15@gmail.com','Comercial','(11)96113-1106',''),(7,21,'Aline','alyne@almeidasusinagens.com.br','Contas a Pagar','',''),(8,47,'Gelson','','Pintor','(12)99641-9308',''),(9,49,'ANTÔNIO','','VENDAS','','(12)4647-8080'),(17,75,'','','','',''),(18,75,'','','','',''),(19,33,'teste','','','','');
/*!40000 ALTER TABLE `tb_agenda` ENABLE KEYS */;
UNLOCK TABLES;

/* SCRIPTS DE VALIDAÇÃO DE DADOS - SISTEMA FLEXIBUS*/      

      function confirma(msg) {
        return confirm(msg);
    }


    function validaCampo(obj)
    {
        for(var i = 0; i<obj.length; i++){
    
            if(obj[i].value=="")
              {
                  alert("Os campos com * são obrigatórios!");
                  return false;
              }
        }
        return true;
    }

     function estq_baixo(etq_max) {
        if (add_item.qtd.value > etq_max) {
            alert("Estoque Insuficiente !!");
            return false;
        }else{
             return true;
        }
    }


    function valida_senha(obj)
    {
        if(obj[1].value != obj[2].value)
          {
              alert("O campo \"Repita a senha\" não confere!");
              return false;
          }

        if (validaCampo(obj)){
            return true;
        }else{
            return false;
        }
    }

 
    function money(campo){
        var ok_chr = new Array('1','2','3','4','5','6','7','8','9','0');
        var text = campo.value;
        var after_dot = 0;
        var out_text = '';
        for(var i = 0; i<text.length; i++){

            if(after_dot > 0){ // conta quantas casas depois da virgula
                after_dot = after_dot + 1;
            }

            if (after_dot < 4 ){ // se não passou de 2 casas depois da virgula ( conta o ponto + 2 digitos)

                if(ok_chr.includes(text.charAt(i))){
                    out_text = out_text + text.charAt(i)

                }
                if((text.charAt(i) == ',' || text.charAt(i) == '.') && after_dot == 0){
                    out_text = out_text + '.';
                    after_dot = after_dot + 1;
                }
            }


        }
        campo.value = out_text;
    }


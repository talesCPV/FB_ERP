<!DOCTYPE HTML>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
    <title>Configuracoes</title>
    <link rel="stylesheet" type="text/css"  href="css/estilo.css" />
    <script src="js/funcoes.js"></script>
</head>
<body>


  <header>
    <?php
      include "menu.inc";
      include "funcoes.inc";  


      $file = "config/nfe.cfg \r\n";
      $topo = "NOTAFISCAL|1 \r\n";
      $A = "A|4.00|| \r\n";

      function limpa_num($num)
      {
        $resp = "";
        for($i=0; i< strlen($num);$i++){
          $R = $num[i];
          if ($R == '0' ||$R == '1' ||$R == '2' ||$R == '3' ||$R == '4' ||$R == '5' ||$R == '6' ||$R == '7' ||$R == '8' ||$R == '9')
          {
            $resp = $resp . $num[i];
          }
        }
        return $resp;
      }

      function get_post_action($name)
      {
          $params = func_get_args();

          foreach ($params as $name) {
              if (isset($_POST[$name])) {
                  return $name;
              }
          }
      }

      function monta()
      {
        global $file, $topo, $A, $B, $C, $C02, $C05, $E, $E02, $E05;
        $fp = fopen($file, "w");
        fwrite($fp, $topo.$A.$B.$C.$C02.$C05.$E.$E02.$E05);
        fclose($fp);
      }



      function make_array($line){ // Recebe uma string e separa os dados entre "|"
        $val = "";
        $count = 0;
        $resp = [];
        for($i = 0; $i < strlen($line); $i++){
          if(substr($line, $i, 1) == "|"){
            $resp[$count] = $val;
            $val = "";
            $count++;
          }else{
            $val = $val . substr($line, $i, 1);
          }

        }

        return $resp;

      }


      function Add_Linha($line)
      {
        global $file;
        $fp = fopen($file, "a");
        fwrite($fp, $line."\r\n");
        fclose($fp);
      }



      function Add_Item($Cod_Pedido){

        include "conecta_mysql.inc";

        if (!$conexao)
          die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

        $query =  "SELECT p.cod, p.descricao, p.ncn, p.unidade, i.qtd, i.preco
                  FROM tb_item_ped as i 
                  INNER JOIN tb_produto AS p
                  ON i.id_ped = '". $Cod_Pedido ."' AND i.id_prod = p.id;";


        $result = mysqli_query($conexao, $query);

        echo $result;


//        $qtd_itens = $result->num_rows;

        $total = 0;
        $count = 1;

        while($fetch = mysqli_fetch_row($result)){
          Add_Linha("H|".$count."||");
          $count++;

          $cProd = $fetch[0];
          $cEAN = "";
          $xProd = $fetch[1];
          $NCM = $fetch[2];
          $cBenef = "";

          $venda = $fetch[4];
          $subtotal = $fetch[3] * $venda;
          $total = $total + $subtotal;

            echo "<tr><td>" .$fetch[0] . "</td>".
                 "<td>" .$fetch[1] . "</td>".
                 "<td>" .$fetch[2] . "</td>".
                 "<td>" .$fetch[3] . "</td>".
                 "<td>" .money_format('%=*(#0.2n', $venda) . "</td>".
                 "<td>" .money_format('%=*(#0.2n', $subtotal) . "</td></tr>";
//            Add_Linha($fetch[1]);
        }


        $conexao->close();


      }


  if (file_exists($file)) {
    $fp = fopen($file, "r");
    while (!feof ($fp)) {
      $str_line = fgets($fp,4096);
      $linha = make_array($str_line); // Transforma a linha num array
      if (sizeof($linha) > 0){
        switch ($linha[0]) {
          case 'B':
            $B = $str_line;
            break;
          case 'C':
            $C = $str_line;
            break;
          case 'C02':
            $C02 = $str_line;
            break;
          case 'C05':
            $C05 = $str_line;
            break;
          default:
              //no action sent
        }
      }
    } 

    fclose($fp);
  }else{

      $B = "B|35||VENDA|55|1||||1|1|3508504|1|1||1|1|0|0|3||||\r\n";
      $C = "C|FLEXIBUS SANFONADOS LTDA|FLEXIBUS|234033845113||||1|\r\n";
      $C02 = "C02|00519547000106|\r\n";
      $C05 = "C05|AV. DR. ROSALVO DE ALMEIDA TELLES|2070||NOVA CAÇAPAVA|3508504|Cacapava|SP|12283020|1058|BRASIL|1236532230|\r\n";
      $E = "E|||||||\r\n";
      $E02 = "E02||\r\n";
      $E05 = "E05|||||||||1058|BRASIL||\r\n";
  }

    ?>
  </header>

<div class="page_container">  
  <div class="page_form">
    <p class="logo"> Configuracao de NFe</p> <br>
    <form class="login-form" name="cadastro" method="POST" action="#" >
      <table>
        <tr>
          <td><button name="emitente" type="submit">Emitente</button></td>
          <td><button name="fiscal" type="submit">Fiscal</button></td>
          <td><button name="pedido" type="submit">Pedido</button></td>
          <td><button type="submit">*</button></td>
          <td><button type="submit">*</button></td>
        </tr>
      </table>
      
    </form>    
  </div>


  <div class="page_form" id="no_margin">

    <?php
      global $file, $topo, $A, $B, $C, $C02, $C05;
      switch (get_post_action('emitente', 'fiscal', 'save_emit', 'save_fiscal', 'pedido', 'gera_nfe')) {
          case 'emitente':
            $C_arr = make_array($C);
            $C02_arr = make_array($C02);
            $C05_arr = make_array($C05);
            echo" <p class=\"logo\"> Dados do Emitente</p> <br>";
            echo"
              <form class=\"login-form\" name=\"cadastro\" method=\"POST\" action=\"#\" onsubmit=\"return validaCampo(new Array(cadastro.nome)); return false;\">
                <label> Razão Social *</label>
                <input type=\"text\" name=\"xNome\" maxlength=\"60\" value=\"". $C_arr[1] ."\" />
                <label> Nome Fantasia </label>
                <input type=\"text\" name=\"xFant\" maxlength=\"60\" value=\"". $C_arr[2] ."\"/>
                <label> Insc. Estadual </label>
                <input type=\"text\" name=\"IE\" maxlength=\"14\" value=\"". $C_arr[3]."\" />
                <input type=\"hidden\" name=\"IEST\"  >                
                <label> Insc. Municipal </label>
                <input type=\"text\" name=\"IM\" maxlength=\"15\" value=\"". $C_arr[5] ."\" />
                <label> CNAE </label>
                <input type=\"text\" name=\"CNAE\" maxlength=\"7\"  value=\"". $C_arr[6] ."\"/>
                <label> Regime Tributário </label>
                <select name=\"CRT\" >
                  <option"; if($C_arr[7] == '1'){echo" selected ";} echo "value=\"1\">Simples Nacional</option>
                  <option"; if($C_arr[7] == '2'){echo" selected ";} echo "value=\"2\">Simples Nacional - excesso de sublimite de receita bruta</option>
                  <option"; if($C_arr[7] == '3'){echo" selected ";} echo "value=\"3\">Regime Normal.</option>
                </select>
                <label> CNPJ </label>
                <input type=\"text\" name=\"CNPJ\" maxlength=\"14\" value=\"". $C02_arr[1] ."\"/>
                <label> Endereço </label>
                <input type=\"text\" name=\"xLgr\" maxlength=\"60\" value=\"". $C05_arr[1] ."\" />
                <label> Número: </label>
                <input type=\"text\" name=\"nro\" maxlength=\"5\" value=\"". $C05_arr[2] ."\" />
                <label> Complemento </label>
                <input type=\"text\" name=\"cpl\" maxlength=\"60\"  value=\"". $C05_arr[3] ."\"/>
                <label> Bairro </label>
                <input type=\"text\" name=\"bairro\" maxlength=\"60\" value=\"". $C05_arr[4] ."\" />
                <label> Código do Municipio </label>
                <input type=\"text\" name=\"cMun\" maxlength=\"60\" value=\"". $C05_arr[5] ."\"/>
                <label>  Nome do Municipio</label>
                <input type=\"text\" name=\"xMun\" maxlength=\"60\" value=\"". $C05_arr[6] ."\"/>
                <label> Sigla da UF </label>
                <input type=\"text\" name=\"UF\" maxlength=\"60\" value=\"". $C05_arr[7] ."\" />
                <label> CEP </label>
                <input type=\"text\" name=\"CEP\" maxlength=\"8\" value=\"". $C05_arr[8] ."\" />
                <label> Código do País  </label>
                <input type=\"text\" name=\"cPais\" maxlength=\"4\" value=\"". $C05_arr[9] ."\" />
                <label> Nome do País </label>
                <input type=\"text\" name=\"xPais\" maxlength=\"60\" value=\"". $C05_arr[10] ."\"/>
                <label> Telefone </label>
                <input type=\"text\" name=\"fone\" maxlength=\"14\" value=\"". $C05_arr[11] ."\" />
                <td><button name=\"save_emit\" type=\"submit\">Salvar</button></td>
              </form>
            ";
            break;

          case 'fiscal':
            $B_arr = make_array($B);

            echo" <p class=\"logo\"> Dados Fiscais</p> <br>";

            echo"
              <form class=\"login-form\" name=\"cadastro\" method=\"POST\" action=\"#\" onsubmit=\"return validaCampo(new Array(cadastro.nome)); return false;\">
                <input type=\"hidden\" name=\"cUF\" value=\"". $B_arr[1] ."\" >      

                <input type=\"hidden\" name=\"cNF\" value=\"". $B_arr[2] ."\" >                

                <label> Natureza da Operação *</label>
                <input type=\"text\" name=\"natOp\" maxlength=\"60\" value=\"". $B_arr[3] ."\" />

                <label> Código do Modelo do Documento Fiscal </label>
                <input type=\"text\" name=\"mod\" maxlength=\"2\" value=\"". $B_arr[4] ."\"  />

                <input type=\"hidden\" name=\"serie\" value=\"". $B_arr[5] ."\" >                

                <label> Numero da NF</label>
                <input type=\"text\" name=\"nNF\" maxlength=\"9\" value=\"". $B_arr[6] ."\" />

                <label> Data de emissão do Documento Fiscal </label>
                <input type=\"date\" name=\"dhEmi\" value=\"". date('Y-m-d') . "\" >

                <label> Data e hora de Saída ou da Entrada da Mercadoria/Produto </label>
                <input type=\"date\" name=\"dhSaiEnt\" value=\"". date('Y-m-d') . "\" >

                <label> Tipo de Operação</label>
                <select name=\"tpNF\" >
                  <option "; if($B_arr[9] == '0'){echo" selected ";} echo "value=\"0\">Entrada</option>
                  <option "; if($B_arr[9] == '1'){echo" selected ";} echo "value=\"1\">Saída</option>
                </select>

                <label> Identificador de Local de destino da operação</label>
                <select name=\"idDest\" >
                  <option "; if($B_arr[10] == '1'){echo"selected ";} echo "value=\"1\">Operação Interna</option>
                  <option "; if($B_arr[10] == '2'){echo"selected ";} echo "value=\"2\">Operação Interestadual</option>
                  <option "; if($B_arr[10] == '3'){echo"selected ";} echo "value=\"3\">Operação com o Exterior</option>
                </select>

                <input type=\"hidden\" name=\"cMunFG\" value=\"". $B_arr[11] ."\" >                

                <label> Formato de Impressão do DANFE</label>
                <select name=\"tpImp\" >
                  <option "; if($B_arr[12] == '1'){echo"selected ";} echo "value=\"1\">Retrato</option>
                  <option "; if($B_arr[12] == '2'){echo"selected ";} echo "value=\"2\">Paisagem</option>
                </select>

                <label>Tipo de Emissão da NF-e</label>
                <select name=\"tpEmis\" >
                  <option "; if($B_arr[13] == '1'){echo"selected ";} echo "value=\"1\">Normal</option>
                  <option "; if($B_arr[13] == '2'){echo"selected ";} echo "value=\"2\">Contingência FS - emissão em contingência com impressão do DANFE em Formulário de Segurança</option>
                  <option "; if($B_arr[13] == '4'){echo"selected ";} echo " value=\"4\">Contingência EPEC - emissão em contingência com envio da Evento Prévio de Emissão em Contingência - EPEC</option>
                  <option "; if($B_arr[13] == '5'){echo"selected ";} echo " value=\"5\">Contingência FS-DA - emissão em contingência com impressão do DANFE em Formulário de Segurança para Impressão de Documento Auxiliar de Documento Fiscal Eletrônico (FS-DA)</option>
                  <option "; if($B_arr[13] == '6'){echo"selected ";} echo " value=\"6\">Contingência SVC-AN</option>
                  <option "; if($B_arr[13] == '7'){echo"selected ";} echo " value=\"7\">Contingência SVC-RS</option>
                  <option "; if($B_arr[13] == '9'){echo"selected ";} echo " value=\"9\">Contingência off-line NFC-e</option>
                </select>

                <input type=\"hidden\" name=\"cDV\" value=\"". $B_arr[14] ."\" >                

                <label> Identificação do Ambiente</label>
                <select name=\"tpAmb\" >
                  <option "; if($B_arr[15] == '1'){echo"selected ";} echo "value=\"1\">Produção</option>
                  <option "; if($B_arr[15] == '2'){echo"selected ";} echo "value=\"2\">Homologação</option>
                </select>

                <label> Finalidade de emissão da NF-e</label>
                <select name=\"finNFe\" >
                  <option "; if($B_arr[16] == '1'){echo"selected ";} echo "value=\"1\">NF-e normal</option>
                  <option "; if($B_arr[16] == '2'){echo"selected ";} echo "value=\"2\">NF-e complementar</option>
                  <option "; if($B_arr[16] == '3'){echo"selected ";} echo "value=\"3\">NF-e de ajuste</option>
                </select>

                <label>Indica operação com o consumidor final</label>
                <select name=\"indFinal\" >
                  <option "; if($B_arr[17] == '1'){echo"selected ";} echo "value=\"1\">Normal</option>
                  <option "; if($B_arr[17] == '2'){echo"selected ";} echo "value=\"2\">Consumidor Final</option>
                </select>

                <label>Indicador de presença do comprador no estabelecimento comercial no momento da operação</label>
                <select name=\"indPres\" >
                  <option "; if($B_arr[18] == '0'){echo"selected ";} echo "value=\"0\">Não se aplica (por exemplo Nota Fiscal Complementar ou de ajuste)</option>
                  <option "; if($B_arr[18] == '1'){echo"selected ";} echo "value=\"1\">Operação presencial</option>
                  <option "; if($B_arr[18] == '2'){echo"selected ";} echo "value=\"2\">Operação não presencial, pela Internet</option>
                  <option "; if($B_arr[18] == '3'){echo"selected ";} echo "value=\"3\">Operação não presencial, pelo tele atendimento</option>
                  <option "; if($B_arr[18] == '4'){echo"selected ";} echo "value=\"4\">NFC-e em operação com entrega em domicílio</option>
                  <option "; if($B_arr[18] == '5'){echo"selected ";} echo "value=\"5\">Operação não presencial, fora do estabelecimento</option>
                  <option "; if($B_arr[18] == '9'){echo"selected ";} echo "value=\"9\">Operação não presencial, outros</option>
                </select>

                <label>Processo de emissão da NF-e</label>
                <select name=\"procEmi\" >
                  <option "; if($B_arr[19] == '0'){echo"selected ";} echo "value=\"0\">emissão de NF-e com aplicativo do contribuinte</option>
                  <option "; if($B_arr[19] == '1'){echo"selected ";} echo "value=\"1\">emissão de NF-e avulsa pelo Fisco</option>
                  <option "; if($B_arr[19] == '2'){echo"selected ";} echo "value=\"2\">emissão de NF-e avulsa, pelo contribuinte com seu certificado digital, através do site do Fisco</option>
                  <option "; if($B_arr[19] == '3'){echo"selected ";} echo "value=\"3\">emissão NF-e pelo contribuinte com aplicativo fornecido pelo Fisco</option>
                </select>


                <input type=\"hidden\" name=\"verProc\" value=\"". $B_arr[20] ."\" >                

                <input type=\"hidden\" name=\"dhCont\" value=\"". $B_arr[21] ."\" >                

                <input type=\"hidden\" name=\"xJust\" value=\"". $B_arr[22] ."\" >                

                <td><button name=\"save_fiscal\" type=\"submit\">Salvar</button></td>

              </form>
            ";
            break;

          case 'pedido': 
            echo" <p class=\"logo\"> Selecione o Pedido </p> <br>";
            echo"
                    <form class=\"login-form\" method=\"POST\" action=\"#\">
                        <table class=\"search-table\"  border=\"0\"><tr><td>
                      <label> Busca por: </label> </td><td>
                      <select name=\"campo_busca\">
                        <option value=\"todos\">Todos</option>
                        <option value=\"cod\">Codigo</option>
                        <option value=\"num_ped\">Numero</option>
                        <option value=\"cliente\">Cliente</option>
                    </select></td><td>
                    <input type=\"text\" name=\"valor_busca\" maxlength=\"12\"/></td><td>
                  <button name=\"pedido\" id=\"botao_inline\" type=\"submit\">OK</button></td></tr>  </table>
                    </form>";

            $qtd_lin = 0;
            if (IsSet($_POST ["campo_busca"])){
              global $conexao;

              include "conecta_mysql.inc";

              if (!$conexao)
                die ("Erro de conexão com localhost, o seguinte erro ocorreu -> ".mysql_error());

                $campo = $_POST ["campo_busca"];
                $valor = $_POST ["valor_busca"];
                if ($campo == "todos"){

                      $query =  "SELECT p.id, p.num_ped, e.nome, e.ie, e.cnpj, e.endereco, p.status, e.num, e.bairro, e.cidade, e.estado, e.cep, e.tel
                                 FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
                                 ON p.id_emp = e.id AND p.status = 'FECHADO';";

                }
                else
                if ($campo == "num_ped"){
                      $query =  "SELECT p.id, p.num_ped, e.nome, e.ie, e.cnpj, e.endereco, p.status, e.num, e.bairro, e.cidade, e.estado, e.cep, e.tel
                                 FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
                                 ON p.id_emp = e.id AND p.num_ped = '". $valor ."' AND p.status = 'FECHADO';";
                }
                else
                if ($campo == "cliente"){
                      $query =  "SELECT p.id, p.num_ped, e.nome, e.ie, e.cnpj, e.endereco, p.status, e.num, e.bairro, e.cidade, e.estado, e.cep, e.tel
                                 FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
                                 ON p.id_emp = e.id AND e.nome LIKE '%".$valor."%' AND p.status = 'FECHADO';";

                }
                else
                if ($campo == "cod"){
                      $query =  "SELECT p.id, p.num_ped, e.nome, e.ie, e.cnpj, e.endereco, p.status, e.num, e.bairro, e.cidade, e.estado, e.cep, e.tel
                                 FROM tb_pedido AS p INNER JOIN tb_empresa AS e 
                                 ON p.id_emp = e.id AND p.id = '". $valor ."' AND p.status = 'FECHADO';";
                }


              $result = mysqli_query($conexao, $query);

              $qtd_lin = $result->num_rows;

  

              echo"  
                  <table class=\"search-table\" >
                            <tr>
                              <th>Cod.</th>
                              <th>Numero</th>
                              <th>Cliente</th>
                              <th>Insc. Est.</th>
                              <th>CNPJ</th>
                      </tr>";
                        while($fetch = mysqli_fetch_row($result)){

                          $cod_ped = $fetch[0];
                          $status = $fetch[6];
                          $xNome = $fetch[2];
                          $IE = $fetch[3]; 
                          $CNPJ = $fetch[4]; 
                          $xLgr = $fetch[5]; 
                          $nro = $fetch[7]; 
                          $xBairro = $fetch[8];
                          $xMun = $fetch[9];
                          $UF = $fetch[10];
                          $CEP = $fetch[11];
                          $fone = $fetch[12];

                            echo "<tr><td>" .$fetch[0] . "</td>".
                             "<td>" .$fetch[1] . "</td>".
                             "<td>" .$fetch[2] . "</td>".
                               "<td>" .$fetch[3] . "</td>".
                               "<td>" . $fetch[4] . "</td></tr>";

                        }


                      echo"
                  </table> 
                ";

              if ($qtd_lin == 1){

                $cMun = IBGE_Mun($UF,$xMun);
                $cUF = IBGE_UF($UF);


          echo " <br><br>

                <form class=\"login-form\" method=\"POST\" action=\"#\">
                  <input type=\"hidden\" name=\"cod_ped\" value=\"".trim($cod_ped) ."\" >                

                  <input type=\"hidden\" name=\"xNome\" value=\"".trim($xNome) ."\" >                
                  <input type=\"text\" name=\"email\" maxlength=\"60\" value=\"".$cMun."-".$cUF ."\"  />
                  <label class=\"logo\"> Finalidade de emissão da NF-e</label>
                  <select name=\"indIEDest\" >
                    <option "; if(trim($IE) != ''){echo"selected ";} echo "value=\"1\">Contribuinte ICMS (informar a IE do destinatário no cadastro da empresa)</option>
                    <option "; if(trim($IE) == ''){echo"selected ";} echo "value=\"2\">Contribuinte isento de Inscrição no cadastro de Contribuintes do ICMS</option>
                    <option value=\"9\">Não Contribuinte, que pode ou não possuir Inscrição Estadual no Cadastro de Contribuintes do ICMS</option>
                  </select>
                  <input type=\"hidden\" name=\"IE\" value=\"". trim($IE) ."\" >                
                  <label class=\"logo\"> Inscrição na SUFRAMA</label>
                  <input type=\"text\" name=\"ISUF\" maxlength=\"9\" value=\"\"  />
                  <input type=\"hidden\" name=\"IM\" value=\"\" >                
                  <label class=\"logo\"> Email</label>
                  <input type=\"text\" name=\"email\" maxlength=\"60\" value=\"\"  />
                  <input type=\"hidden\" name=\"CNPJ\" value=\"". trim($CNPJ) ."\" >                
                  <input type=\"hidden\" name=\"xLgr\" value=\"". trim($xLgr) ."\" >                
                  <input type=\"hidden\" name=\"nro\" value=\"". trim($nro) ."\" >                
                  <input type=\"hidden\" name=\"XCpl\" value=\"\" >                
                  <input type=\"hidden\" name=\"xBairro\" value=\"".trim($xBairro)."\" >                
                  <input type=\"hidden\" name=\"cMun\" value=\"".trim($cMun)."\" >                
                  <input type=\"hidden\" name=\"xMun\" value=\"".trim($xMun)."\" >                
                  <input type=\"hidden\" name=\"UF\" value=\"".trim($UF)."\" >                
                  <input type=\"hidden\" name=\"CEP\" value=\"". limpa_num($CEP)."\" >                
                  <input type=\"hidden\" name=\"cPais\" value=\"1058\" >                
                  <input type=\"hidden\" name=\"xPais\" value=\"BRASIL\" >                
                  <input type=\"hidden\" name=\"fone\" value=\"".limpa_num($fone)."\" >                
                  <br><br> <td><button name=\"gera_nfe\" type=\"submit\">Gerar NFe</button></td>

                </form>";
              } 

            $conexao->close();

            }
            break;

          case 'save_fiscal': 
            $B = "B|".$_POST ["cUF"]."|".$_POST ["cNF"]."|".$_POST ["natOp"]."|".$_POST ["mod"]."|".$_POST ["serie"]."|".$_POST ["nNF"]."|".$_POST ["dhEmi"]."T".date('H:i:s')."-03:00|".$_POST ["dhSaiEnt"]."T19:00:00-03:00|".$_POST ["tpNF"]."|".$_POST ["idDest"]."|".$_POST ["cMunFG"]."|".$_POST ["tpImp"]."|".$_POST ["tpEmis"]."|".$_POST ["cDV"]."|".$_POST ["tpAmb"]."|".$_POST ["finNFe"]."|".$_POST ["indFinal"]."|".$_POST ["indPres"]."|".$_POST ["procEmi"]."|".$_POST ["verProc"]."|".$_POST ["dhCont"]."|".$_POST ["xJust"]."|\r\n";
            monta();

            break;

          case 'save_emit':   
            $C = "C|".$_POST ["xNome"]."|".$_POST ["xFant"]."|".$_POST ["IE"]."|".$_POST ["IEST"]."|".$_POST ["IM"]."|".$_POST ["CNAE"]."|".$_POST ["CRT"]."|\r\n";
            $C02 = "C02|".$_POST ["CNPJ"]."|\r\n";
            $C05 = "C05|".$_POST ["xLgr"]."|".$_POST ["nro"]."|".$_POST ["cpl"]."|".$_POST ["bairro"]."|".$_POST ["cMun"]."|".$_POST ["xMun"]."|".$_POST ["UF"]."|".$_POST ["CEP"]."|".$_POST ["cPais"]."|".$_POST ["xPais"]."|".$_POST ["fone"]."|\r\n";
            monta();

            break;

          case 'gera_nfe':  

            $E = "E|".$_POST ["xNome"]."|".$_POST ["indIEDest"]."|".$_POST ["IE"]."|".$_POST ["ISUF"]."|".$_POST ["IM"]."|".$_POST ["email"]."|\r\n";
            $E02 = "E02|".$_POST ["CNPJ"]."|\r\n";
            $E05 = "E05|".$_POST ["xLgr"]."|".$_POST ["nro"]."|".$_POST ["XCpl"]."|".$_POST ["xBairro"]."|".$_POST ["cMun"]."|".$_POST ["xMun"]."|".$_POST ["UF"]."|".$_POST ["CEP"]."|".$_POST ["cPais"]."|".$_POST ["xPais"]."|".$_POST ["fone"]."|\r\n";

            monta();

            Add_Item($_POST ["cod_ped"]);

            break;


          default:
              //no action sent
        }

    ?>
  </div>

</div>


</body>
</html>